process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)
const TelegramBot = require('node-telegram-bot-api');
const { Client } = require('ssh2');
const { exec } = require('child_process');
const fs = require('fs');
const fetch = require("node-fetch");
const axios = require('axios');
const chalk = require('chalk');
//const owner = config.adminId;
const settings = require('./config');
const owner = settings.adminId;
const botToken = settings.token;
const adminfile = './data/adminID.json';
const premiumUsersFile = './data/premiumUsers.json';
const pendingRequests = {};
const domain = settings.domain;
const plta = settings.ptla;
const pltc = settings.ptlc;
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}
const bot = new TelegramBot(botToken, { polling: true });
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
}
const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}
 // password random 3 char terakhir
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const rand3 = Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
function getRuntime(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
// File untuk logging
const logFile = 'bot.log';

// Fungsi untuk menulis log ke file dan console
function logToFileAndConsole(message) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage);
  fs.appendFileSync(logFile, logMessage);
}

let serverpanel = [];
const filePath = "./data/data-cpanel.json";

// load data lama biar ga ke-reset
if (fs.existsSync(filePath)) {
  serverpanel = JSON.parse(fs.readFileSync(filePath));
}

// helper cek owner
function isOwner(userId) {
  return userId.toString() === owner;
}

// Scrape proxy dari sumber yang diberikan
async function scrapeProxies() {
  const proxySources = [
    'https://api.proxyscrape.com/v3/free-proxy-list/get?request=displayproxies&protocol=http&proxy_format=ipport&format=text&timeout=20000',
    'https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt',
    'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt',
    'https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt',
    'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt',
    'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt',
    'https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt',
    'https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt',
    'https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt',
    'https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt',
    'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
    'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt',
    'https://raw.githubusercontent.com/HumayunShariarHimu/Proxy/main/Anonymous_HTTP_One.md',
    'https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/https.txt',
    'https://raw.githubusercontent.com/ArrayIterator/proxy-lists/main/proxies/http.txt',
    'https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt',
    'https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt',
    'https://raw.githubusercontent.com/elliottophellia/proxylist/master/results/http/global/http_checked.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt',
    "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks4.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
"https://raw.githubusercontent.com/zloi-user/hideip.me/main/connect.txt",
"https://raw.githubusercontent.com/zevtyardt/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/socks5.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/socks4.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/proxy.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/https.txt",
"https://raw.githubusercontent.com/Zaeem20/FREE_PROXIES_LIST/master/http.txt",
"https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt",
"https://raw.githubusercontent.com/yogendratamang48/ProxyList/master/proxies.txt",
"https://raw.githubusercontent.com/yemixzy/proxy-list/master/proxies.txt",
"https://raw.githubusercontent.com/yemixzy/proxy-list/main/proxies/unchecked.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/https.txt",
"https://raw.githubusercontent.com/Vann-Dev/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks5.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks4.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/proxylist.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt",
"https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
"https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/socks5.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/socks5.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/socks4.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/socks4.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/http.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/http.txt",
"https://raw.githubusercontent.com/tuanminpay/live-proxy/master/all.txt",
"https://raw.githubusercontent.com/TuanMinPay/live-proxy/master/all.txt",
"https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/https.txt",
"https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/http.txt",
"https://raw.githubusercontent.com/Tsprnay/Proxy-lists/master/proxies/all.txt",
"https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",
"https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
"https://raw.githubusercontent.com/TheSpeedX/PROXY-List/blob/master/socks4.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/socks5_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/socks4_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/generated/http_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/generated/socks5_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/generated/socks4_proxies.txt",
"https://raw.githubusercontent.com/sunny9577/proxy-scraper/main/generated/http_proxies.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
"https://raw.githubusercontent.com/shiftytr/proxy-list/master/proxy.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/proxy.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
"https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/working.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/ultrafast.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/socks5.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/socks4.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/premium.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/new.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/http.txt",
"https://raw.githubusercontent.com/saschazesiger/Free-Proxies/master/proxies/fast.txt",
"https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/free.txt",
"https://raw.githubusercontent.com/saisuiu/Lionkings-Http-Proxys-Proxies/main/cnfree.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks5.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/socks4.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/https.txt",
"https://raw.githubusercontent.com/RX4096/proxy-list/main/online/http.txt",
"https://raw.githubusercontent.com/rx443/proxy-list/main/online/https.txt",
"https://raw.githubusercontent.com/rx443/proxy-list/main/online/http.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",,
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
"https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTP_RAW.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/socks5.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/socks4.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies_anonymous/http.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/socks5.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/prxchk/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/socks5.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/socks4.txt",
"https://raw.githubusercontent.com/ProxyScraper/ProxyScraper/main/http.txt",
"https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks5.txt",
"https://raw.githubusercontent.com/proxylist-to/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt",
"https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt",
"https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/RAW.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/xResults/old-data/Proxies.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks5/socks5.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/socks4/socks4.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/https/https.txt",
"https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/socks5.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/socks4.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/https.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/http.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/socks5.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/socks4.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/https.txt",
"https://raw.githubusercontent.com/ObcbO/getproxy/master/file/http.txt",
"https://raw.githubusercontent.com/mython-dev/free-proxy-4000/main/proxy-4000.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/https.txt",
"https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
"https://raw.githubusercontent.com/MrMarble/proxy-list/main/all.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks5.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/socks4.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies_anonymous/http.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/https.txt",
"https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
"https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
"https://raw.githubusercontent.com/miyukii-chan/proxy-list/master/proxies/http.txt",
"https://raw.githubusercontent.com/mishakorzik/Free-Proxy/main/proxy.txt",
"https://raw.githubusercontent.com/mertguvencli/http-proxy-list/main/proxy-list/data.txt",
"https://raw.githubusercontent.com/manuGMG/proxy-365/main/SOCKS5.txt",
"https://raw.githubusercontent.com/mallisc5/master/proxy-list-raw.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt",
"https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
"https://raw.githubusercontent.com/j0rd1s3rr4n0/api/main/proxy/http.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/socks5.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/socks4.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/https.txt",
"https://raw.githubusercontent.com/ItzRazvyy/ProxyList/main/http.txt",
"https://raw.githubusercontent.com/im-razvan/proxy_list/main/socks5",
"https://raw.githubusercontent.com/im-razvan/proxy_list/main/http.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/socks5.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/socks4.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/https.txt",
"https://raw.githubusercontent.com/HyperBeats/proxy-list/main/http.txt",
"https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
"https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt",
"https://raw.githubusercontent.com/fate0/proxylist/master/proxy.list",
"https://raw.githubusercontent.com/fahimscirex/proxybd/master/proxylist/socks4.txt",
"https://raw.githubusercontent.com/fahimscirex/proxybd/master/proxylist/http.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/https.txt",
"https://raw.githubusercontent.com/ErcinDedeoglu/proxies/main/proxies/http.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/socks5.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/socks4.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/https.txt",
"https://raw.githubusercontent.com/enseitankado/proxine/main/proxy/http.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/socks5/global/socks5_checked.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/socks4/global/socks4_checked.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/mix_checked.txt",
"https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/http/global/http_checked.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/https.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/http.txt",
"https://raw.githubusercontent.com/dunno10-a/proxy/main/proxies/all.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/socks5.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/socks4.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/proxylist.txt",
"https://raw.githubusercontent.com/Daesrock/XenProxy/main/https.txt",
"https://raw.githubusercontent.com/crackmag/proxylist/proxy/proxy.list",
"https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list.txt",
"https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/socks5",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/socks4",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/https",
"https://raw.githubusercontent.com/casals-ar/proxy-list/main/http",
"https://raw.githubusercontent.com/caliphdev/Proxy-List/master/http.txt",
"https://raw.githubusercontent.com/caliphdev/Proxy-List/main/socks5.txt",
"https://raw.githubusercontent.com/caliphdev/Proxy-List/main/http.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/socks5.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/socks4.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/https.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/http.txt",
"https://raw.githubusercontent.com/BreakingTechFr/Proxy_Free/main/proxies/all.txt",
"https://raw.githubusercontent.com/BlackCage/Proxy-Scraper-and-Verifier/main/Proxies/Not_Processed/proxies.txt",
"https://raw.githubusercontent.com/berkay-digital/Proxy-Scraper/main/proxies.txt",
"https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt",
"https://raw.githubusercontent.com/aslisk/proxyhttps/main/https.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks5_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/socks4_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt",
"https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt",
"https://raw.githubusercontent.com/andigwandi/free-proxy/main/proxy_list.txt",
"https://raw.githubusercontent.com/almroot/proxylist/master/list.txt",
"https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/socks5.txt",
"https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt",
"https://raw.githubusercontent.com/a2u/free-proxy-list/master/free-proxy-list.txt",
"https://proxyspace.pro/socks5.txt",
"https://proxyspace.pro/socks4.txt",
"https://proxyspace.pro/https.txt",
"https://proxyspace.pro/http.txt",
"https://proxy-spider.com/api/proxies.example.txt",
"https://openproxylist.xyz/socks5.txt",
"https://openproxylist.xyz/socks4.txt",
"https://openproxylist.xyz/https.txt",
"https://openproxylist.xyz/http.txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=socks5&format=txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=socks4&format=txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=https&format=txt",
"https://naawy.com/api/public/proxylist/getList/?proxyType=http&format=txt",
"https://multiproxy.org/txt_all/proxy.txt",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous",
"https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
"https://api.proxyscrape.com/v2/?request=displayproxies",
"https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all",
"https://api.proxyscrape.com/?request=displayproxies&proxytype=http",
"https://api.openproxylist.xyz/socks5.txt",
"https://api.openproxylist.xyz/socks4.txt",
"https://api.openproxylist.xyz/http.txt",
"https://api.good-proxies.ru/getfree.php?count=1000&key=freeproxy"
  ];

  let proxies = [];

    // Hapus file proxy.txt lama
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
    logToFileAndConsole('proxy.txt lama berhasil dihapus');
  }
  
  for (const source of proxySources) {
    try {
      const response = await axios.get(source);
      proxies = proxies.concat(response.data.split('\n'));
    } catch (error) {
      logToFileAndConsole(`Error scraping proxies from ${source}: ${error.message}`);
    }
  }

  fs.writeFileSync('proxy.txt', proxies.join('\n'));
  logToFileAndConsole('Proxies successfully scraped and saved to proxy.txt');
}

// Mulai dengan scraping proxy saat bot dijalankan
scrapeProxies();
const nama = 'Ibra Decode';
const author = 'Ibra Decode';
// Informasi waktu mulai bot
const startTime = Date.now();
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Event Listener untuk Command /start
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const runtime = getRuntime(startTime);
  
  bot.sendPhoto(chatId, 'https://files.catbox.moe/7l5fvh.jpg', {
    caption: `\`\`\`ⓘXMsbra
(🂱) Halo' ${username}
━━━━━━━━━━━━━━━━━
⟮ Info Script ⟯
Developer : @ibradecode 
Name Bot : XMsbra 
Type Bot  : CPanel Only
Version    : 1.0
Language  : JavaScript
Waktu     : ${runtime}
 
# Select The Button View Menu.
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
            inline_keyboard: [
                [{ text: 'MenuPanel', callback_data: 'menupanel' }],
                [{ text: 'OwnerMenu', callback_data: 'ownermenu' }],
                [{ text: 'ListRam', callback_data: 'listram' }],
                [{ text: 'tutorial', callback_data: 'tutorial' }]
      ]
    }
  });
});

bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;
    const runtime = getRuntime(startTime);
    
    let caption = "";
    let replyMarkup = {};

    if (query.data === "menupanel") {
      caption = `\`\`\`ⓘXMsbra
(🂱) Halo' ${username}
━━━━━━━━━━━━━━━━━
⟮ Panel Menu ⟯
/buatpanel
/listpanel
/delpanel
/addsrv
/delsrv
/editsrv
/listsrv
/adp
/listadmin
/clearserver
\`\`\``;
      replyMarkup = { inline_keyboard: [[{ text: "🔙𝗕𝗮𝗰𝗸", callback_data: "back_to_main" }]] };
    }
    
    if (query.data === "ownermenu") {
      caption = `\`\`\`ⓘXMsbra
(🂱) Halo' ${username}
━━━━━━━━━━━━━━━━━
⟮ Owner Menu ⟯
/addprem
/delprem
/adp
/addsrv
/delsrv
/listsrv
/editsrv
/listadmin
\`\`\``;
      replyMarkup = { inline_keyboard: [[{ text: "🔙𝗕𝗮𝗰𝗸", callback_data: "back_to_main" }]] };
    }

    if (query.data === "listram") {
      caption = `\`\`\`ⓘXMsbra
(🂱) Halo' ${username}
━━━━━━━━━━━━━━━━━
⟮ List Ram ⟯
=> 1GB ( PREMIUM ) ✅
=> 2GB ( PREMIUM ) ✅
=> 3GB ( PREMIUM ) ✅
=> 4GB ( PREMIUM ) ✅
=> 5GB ( PREMIUM ) ✅
=> 6GB ( PREMIUM ) ✅
=> 7GB ( PREMIUM ) ✅
=> 8GB ( PREMIUM ) ✅
=> 9GB ( PREMIUM ) ✅
=> 10GB ( PREMIUM ) ✅
=> 11GB ( PREMIUM ) ✅
=> 12GB ( PREMIUM ) ✅
=> 13GB ( PREMIUM ) ✅
=> 14GB ( PREMIUM ) ✅
=> 15GB ( PREMIUM ) ✅
=> UNLI( PREMIUM ) ✅

JOIN RESELLER/ ADMIN PANEL DAN LAINNYA BISA PV AJA
https://t.me/ibradecode
\`\`\``;
      replyMarkup = { inline_keyboard: [[{ text: "🔙𝗕𝗮𝗰𝗸", callback_data: "back_to_main" }]] };
    }

    if (query.data === "tutorial") {
      caption = `\`\`\`ⓘXMsbra
(🂱) Halo' ${username}
━━━━━━━━━━━━━━━━━
⟮ Tutorial / Helper ⟯
CARA BIKIN PANEL 

contoh : /buatpanel 1gb

UNTUK ID TELE NYA BISA CEK KETIK /cekid 

𝗕𝘂𝘆 𝗣𝗿𝗲𝗺? @ibradecode
Developer : @ibradecode
\`\`\``;
      replyMarkup = { inline_keyboard: [[{ text: "🔙𝗕𝗮𝗰𝗸", callback_data: "back_to_main" }]] };
    }
      
    if (query.data === "back_to_main") {
      caption = `\`\`\`ⓘXMsbra
(🂱) Halo' ${username}
━━━━━━━━━━━━━━━━━
⟮ Info Script ⟯
Developer : @ibradecode 
Name Bot : XMsbra 
Type Bot  : CPanel Only
Version    : 1.0
Language  : JavaScript
Waktu     : ${runtime}
 
# Select The Button View Menu.
\`\`\``;
    replyMarkup = {
            inline_keyboard: [
                [{ text: 'MenuPanel', callback_data: 'menupanel' }],
                [{ text: 'OwnerMenu', callback_data: 'ownermenu' }],
                [{ text: 'ListRam', callback_data: 'listram' }],
                [{ text: 'tutorial', callback_data: 'tutorial' }]
      ]
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: "https://files.catbox.moe/7l5fvh.jpg",
        caption: caption,
        parse_mode: "Markdown"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("Error handling callback query:", error);
  }
});
//━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//===================MENU CPANEL===≈====≈============//
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// ========================= //
// ===== /addsrv =========== //
// ========================= //
bot.onText(/^\/addsrv (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  let dt = text.split("|");
  if (dt.length < 6) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah bro!\n\nContoh:\n`/addsrv ibraax.co.id|15|5|1|APIKEY|CAPIKEY`",
      { parse_mode: "Markdown" }
    );
  }

  let [dom, eg, nest, locc, ptla, ptlc] = dt;
  const domainFull = `https://${dom}`;

  // cek duplicate
  if (serverpanel.some(s => s.domain === domainFull)) {
    return bot.sendMessage(chatId, "⚠️ Domain itu udah ada bos, gausah ditambah lagi.");
  }

  const ibraax = {
    domain: domainFull,
    egg: eg,
    nestid: nest,
    loc: locc,
    apikey: ptla,
    capikey: ptlc,
  };

  serverpanel.push(ibraax);
  fs.writeFileSync(filePath, JSON.stringify(serverpanel, null, 2));

  bot.sendMessage(chatId, `✅ Server *${dom}* udah masuk daftar boss.`, {
    parse_mode: "Markdown",
  });
});

// ========================= //
// ===== /listsrv ========== //
// ========================= //
bot.onText(/^\/listsrv$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  if (serverpanel.length < 1) {
    return bot.sendMessage(chatId, "📭 Belum ada server yang kesimpen.");
  }

  let teks = "🖥 *List Server Panel*\n";
  serverpanel.forEach((e, i) => {
    teks += `\n${i + 1}. ${e.domain.replace("https://", "")}`;
  });

  bot.sendMessage(chatId, teks, {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "🗑 Hapus Server Panel", callback_data: "delsrv" }],
        [{ text: "👨‍💻 Developer", url: "https://t.me/usernamekamu" }],
      ],
    },
  });
});

// ========================= //
// ===== /delsrv =========== //
// ========================= //
bot.onText(/^\/delsrv (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const index = parseInt(match[1]) - 1;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  if (isNaN(index) || index < 0 || index >= serverpanel.length) {
    return bot.sendMessage(chatId, "⚠️ Nomor server ga valid.");
  }

  let removed = serverpanel.splice(index, 1)[0];
  fs.writeFileSync(filePath, JSON.stringify(serverpanel, null, 2));

  bot.sendMessage(chatId, `🗑 Server *${removed.domain}* udah dihapus.`, {
    parse_mode: "Markdown",
  });
});

// ========================= //
// ===== Callback tombol === //
// ========================= //
bot.on("callback_query", (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data;

  if (data === "delsrv") {
    bot.sendMessage(
      msg.chat.id,
      "Ketik aja `/delsrv nomor` buat hapus server.\nContoh: `/delsrv 1`",
      { parse_mode: "Markdown" }
    );
  }
});
// ========================= //
// ===== /editsrv ========== //
// ========================= //
// contoh: /editsrv 1|apikey|APIKEY_BARU
bot.onText(/^\/editsrv (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  let dt = text.split("|");
  if (dt.length < 3) {
    return bot.sendMessage(
      chatId,
      "⚠️ Format salah.\n\nContoh:\n`/editsrv 1|apikey|APIKEY_BARU`",
      { parse_mode: "Markdown" }
    );
  }

  let [idx, field, newValue] = dt;
  let index = parseInt(idx) - 1;

  if (isNaN(index) || index < 0 || index >= serverpanel.length) {
    return bot.sendMessage(chatId, "⚠️ Nomor server ga valid.");
  }

  // validasi field
  let validFields = ["domain", "egg", "nestid", "loc", "apikey", "capikey"];
  if (!validFields.includes(field)) {
    return bot.sendMessage(
      chatId,
      `⚠️ Field *${field}* ga valid.\n\nYang bisa diedit: ${validFields.join(", ")}`,
      { parse_mode: "Markdown" }
    );
  }

  // kalau domain → pastiin tambah https://
  if (field === "domain") {
    newValue = `https://${newValue}`;
    if (serverpanel.some((s, i) => s.domain === newValue && i !== index)) {
      return bot.sendMessage(chatId, "⚠️ Domain itu udah dipake server lain bos.");
    }
  }

  // update data
  serverpanel[index][field] = newValue;
  fs.writeFileSync(filePath, JSON.stringify(serverpanel, null, 2));

  bot.sendMessage(
    chatId,
    `✅ Data server nomor *${idx}* berhasil diupdate.\nField *${field}* → \`${newValue}\``,
    { parse_mode: "Markdown" }
  );
});
// ========================= //
// ===== /srvinfo ========== //
// ========================= //
// contoh: /srvinfo 1
bot.onText(/^\/srvinfo (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const idx = parseInt(match[1]) - 1;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  if (isNaN(idx) || idx < 0 || idx >= serverpanel.length) {
    return bot.sendMessage(chatId, "⚠️ Nomor server ga valid.");
  }

  const s = serverpanel[idx];
  let teks = `🖥 *Server Info [${idx + 1}]*\n\n`;
  teks += `🌐 Domain: \`${s.domain}\`\n`;
  teks += `🥚 Egg: ${s.egg}\n`;
  teks += `📦 NestID: ${s.nestid}\n`;
  teks += `📍 Lokasi: ${s.loc}\n`;
  teks += `🔑 API Key: \`${s.apikey}\`\n`;
  teks += `🔐 CA Key: \`${s.capikey}\`\n`;

  bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
});
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
bot.onText(/\/buatpanel (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const paket = match[1].toLowerCase();

  // cek premium
  const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(userId));
  if (!isPremium) {
    return bot.sendMessage(chatId, '❌ Command ini cuma buat *Users Premium*.', {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: '💬 Hubungi Admin', url: 'https://t.me/ibradecode' }]]
      }
    });
  }

  const key = `${chatId}_${userId}`;
  pendingRequests[key] = { step: "username", paket };

  bot.sendMessage(chatId, `📝 <a href="tg://user?id=${userId}">Kak</a>, masukin username panel:`, { parse_mode: "HTML" });
});

// handler balasan user (username & idtele)
bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const key = `${chatId}_${userId}`;

  if (!pendingRequests[key]) return;

  const state = pendingRequests[key];

  if (state.step === "username") {
    state.username = msg.text.trim();
    state.step = "idtele";
    return bot.sendMessage(chatId, `📱 <a href="tg://user?id=${userId}">Oke</a>, sekarang masukin ID Telegram:`, { parse_mode: "HTML" });
  }

  if (state.step === "idtele") {
    state.idtele = msg.text.trim();
    state.step = "chooseServer";

    const serverpanel = JSON.parse(fs.readFileSync("./data/data-cpanel.json"));
    if (serverpanel.length < 1) {
      delete pendingRequests[key];
      return bot.sendMessage(chatId, "❌ Belum ada server panel tersimpan.");
    }

    const buttons = serverpanel.map((srv, i) => [
      { text: `🌐 Server ${i + 1} - ${srv.domain}`, callback_data: `chooseServer_${chatId}_${userId}_${i}` }
    ]);

    return bot.sendMessage(chatId, `📡 <a href="tg://user?id=${userId}">Silakan pilih server</a> untuk buat panel:`, {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    });
  }
});

// handler pilih server → bikin panel
bot.on("callback_query", async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;
  const userId = query.from.id;

  if (data.startsWith("chooseServer_")) {
    const [ , reqChatId, reqUserId, index ] = data.split("_");
    if (reqChatId != chatId || reqUserId != userId) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Ini bukan request kamu.", show_alert: true });
    }

    const key = `${chatId}_${userId}`;
    const state = pendingRequests[key];
    if (!state) return bot.answerCallbackQuery(query.id, { text: "❌ Tidak ada request aktif.", show_alert: true });

    const serverpanel = JSON.parse(fs.readFileSync("./data/data-cpanel.json"));
    const panel = serverpanel[parseInt(index)];

    bot.answerCallbackQuery(query.id, { text: `✅ Server ${parseInt(index) + 1} dipilih!` });

    // ambil input user
    const { paket, username } = state;
    const domain = panel.domain;
    const plta = panel.apikey;
    const egg = panel.egg;
    const loc = panel.loc;

    // hitung resource
    let memo, cpu, disk;
    if (paket.endsWith("gb")) {
      const gb = parseInt(paket.replace("gb", ""));
      memo = (gb * 1024).toString();
      cpu = (gb * 30).toString();
      disk = (gb * 1024).toString();
    } else if (paket === "unli") {
      memo = "0"; cpu = "0"; disk = "0";
    } else {
      delete pendingRequests[key];
      return bot.sendMessage(chatId, "⚠️ Paket tidak dikenal. Pilih: `1gb` - `10gb` atau `unli`.", { parse_mode: "Markdown" });
    }

    const rand3 = Math.floor(Math.random() * 1000);
    const password = `${username}${paket}${rand3}`;
    const email = `${username}@ibra.biz.id`;

    const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

    try {
      // buat user di Ptero
      const response = await fetch(`${domain}/api/application/users`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${plta}`
        },
        body: JSON.stringify({
          email: email,
          username: username,
          first_name: username,
          last_name: username,
          language: 'en',
          password: password
        })
      });
      const dataUser = await response.json();
      if (dataUser.errors) {
        delete pendingRequests[key];
        return bot.sendMessage(chatId, `❌ Error buat user: ${JSON.stringify(dataUser.errors[0], null, 2)}`);
      }
      const user = dataUser.attributes;

      // buat server di Ptero
      const response2 = await fetch(`${domain}/api/application/servers`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${plta}`
        },
        body: JSON.stringify({
          name: `${username}-${paket}`,
          description: '',
          user: user.id,
          egg: parseInt(egg),
          docker_image: 'ghcr.io/parkervcp/yolks:nodejs_20',
          startup: spc,
          environment: {
            INST: 'npm',
            USER_UPLOAD: '0',
            AUTO_UPDATE: '0',
            CMD_RUN: 'npm start'
          },
          limits: { memory: memo, swap: 0, disk: disk, io: 500, cpu: cpu },
          feature_limits: { databases: 5, backups: 5, allocations: 1 },
          deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
        })
      });
      const dataServer = await response2.json();
      const server = dataServer.attributes;

      bot.sendMessage(chatId, 
`◻ *SuccessFully Panel Created*
──────────────────────
┏◘ 𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞 : \`${username}\`
┣◘ 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝 : ||${password}||
┗◘ 𝐖𝐞𝐛 𝐋𝐨𝐠𝐢𝐧 :  ${domain}
──────────────────────
\`${paket.toUpperCase()} | ${server.limits.disk} | ${server.limits.cpu}%\`

*📑  Kebijakan & Ketentuan*
- ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴʏᴇʙᴀʀ ᴅᴀᴛᴀ ɪɴɪ
- ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴʏᴇʙᴀʀ ᴅᴏᴍᴀɪɴ
- ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴʏᴀʙᴏᴛᴀsᴇ sᴇʀᴠᴇʀ
- ᴅɪʟᴀʀᴀɴɢ ᴅᴅᴏs & ʀᴜɴ ʙᴏᴛ ᴅᴅᴏs
- sɪᴍᴘᴀɴ ᴅᴀᴛᴀ ɪɴɪ ʙᴀɪᴋ²
- ɢᴀʀᴀɴsɪ 15ʜᴀʀɪ 1x ʀᴇᴘʟᴀᴄᴇ`,
      {
        parse_mode: "MarkdownV2",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📋 Salin Username", callback_data: `copy_user_${username}` },
              { text: "📋 Salin Password", callback_data: `copy_pass_${password}` }
            ],
            [
              { text: "🌐 Website Login", url: domain }
            ]
          ]
        }
      });

    } catch (err) {
      bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }

    delete pendingRequests[key]; // bersihin state
  }

  // tombol salin
  if (data.startsWith("copy_user_")) {
    const user = data.replace("copy_user_", "");
    bot.answerCallbackQuery(query.id, { text: `Username: ${user}`, show_alert: true });
  }
  if (data.startsWith("copy_pass_")) {
    const pass = data.replace("copy_pass_", "");
    bot.answerCallbackQuery(query.id, { text: `Password: ${pass}`, show_alert: true });
  }
});

// === COMMAND /clearserver ===
bot.onText(/\/clearserver/, async (msg) => {
  const chatId = msg.chat.id;

  const serverpanel = JSON.parse(fs.readFileSync("./data/data-cpanel.json"));
  if (serverpanel.length < 1) return bot.sendMessage(chatId, "❌ Belum ada server panel tersimpan.");

  // bikin tombol list domain
  const buttons = serverpanel.map((p, i) => [{ text: `${i + 1}. ${p.domain}`, callback_data: `choosepanel_${i}` }]);

  bot.sendMessage(chatId, "🔍 Pilih domain panel yang mau di-clear servernya:", {
    reply_markup: { inline_keyboard: buttons }
  });
});

// === HANDLE CALLBACK ===
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("choosepanel_")) {
    const index = parseInt(data.replace("choosepanel_", ""));
    const serverpanel = JSON.parse(fs.readFileSync("./data/data-cpanel.json"));
    const panel = serverpanel[index];

    if (!panel) return bot.answerCallbackQuery(query.id, { text: "⚠️ Panel tidak ditemukan", show_alert: true });

    bot.sendMessage(chatId, `⚠️ Yakin mau clear server offline > 2 hari di panel:\n\n🌐 ${panel.domain}`, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "✅ Ya", callback_data: `confirmclear_${index}` },
            { text: "❌ Tidak", callback_data: "cancelclear" }
          ]
        ]
      }
    });
  }

  if (data.startsWith("confirmclear_")) {
    const index = parseInt(data.replace("confirmclear_", ""));
    const serverpanel = JSON.parse(fs.readFileSync("./data/data-cpanel.json"));
    const panel = serverpanel[index];
    if (!panel) return bot.answerCallbackQuery(query.id, { text: "⚠️ Panel tidak ditemukan", show_alert: true });

    bot.sendMessage(chatId, `🔄 Sedang proses clear server di **${panel.domain}**...`, { parse_mode: "Markdown" });

    const hasil = await clearServerForDomain(panel.domain, panel.apikey);

    if (hasil.deleted.length > 0) {
      bot.sendMessage(chatId, `✅ Clear server selesai untuk domain: *${panel.domain}*\n\n🔻 Server yang dihapus:\n- ${hasil.deleted.join("\n- ")}`, { parse_mode: "Markdown" });
    } else {
      bot.sendMessage(chatId, `✅ Clear server selesai untuk domain: *${panel.domain}*\n\nℹ️ Tidak ada server yang perlu dihapus.`, { parse_mode: "Markdown" });
    }
  }

  if (data === "cancelclear") {
    bot.sendMessage(chatId, "❌ Clear server dibatalkan.");
  }
});

// === fungsi clear khusus 1 panel ===
async function clearServerForDomain(domain, apikey) {
  const historyFile = "./data/server-history.json";
  if (!fs.existsSync(historyFile)) fs.writeFileSync(historyFile, JSON.stringify({}));
  let history = JSON.parse(fs.readFileSync(historyFile));

  const deleted = [];

  try {
    const resp = await fetch(`${domain}/api/application/servers`, {
      headers: { "Authorization": `Bearer ${apikey}`, "Accept": "application/json" }
    });
    const data = await resp.json();
    if (!data.data) return { deleted };

    for (const s of data.data) {
      const serverId = s.attributes.id;
      const identifier = s.attributes.identifier;
      const serverName = s.attributes.name;

      const res2 = await fetch(`${domain}/api/client/servers/${identifier}/resources`, {
        headers: { "Authorization": `Bearer ${apikey}`, "Accept": "application/json" }
      });
      const stat = await res2.json();
      const isOffline = stat.attributes?.current_state !== "running";

      const key = `${domain}-${serverId}`;
      const now = Date.now();

      if (isOffline) {
        if (!history[key]) {
          history[key] = now; // catat pertama kali offline
        } else {
          const diff = (now - history[key]) / (1000 * 60 * 60 * 24); // dalam hari
          if (diff >= 2) {
            await fetch(`${domain}/api/application/servers/${serverId}`, {
              method: "DELETE",
              headers: { "Authorization": `Bearer ${apikey}`, "Accept": "application/json" }
            });
            console.log(`❌ Server ${serverName} dihapus (offline > 2 hari).`);
            deleted.push(serverName);
            delete history[key];
          }
        }
      } else {
        if (history[key]) delete history[key];
      }
    }
  } catch (e) {
    console.error(`Error clear server di ${domain}:`, e.message);
  }

  fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));
  return { deleted };
}

// === command /listpanel ===
let panelList = JSON.parse(fs.readFileSync("./data/data-cpanel.json", "utf-8"));

// ─────────── Command /listpanel ───────────
bot.onText(/^\/listpanel$/, async (msg) => {
    const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  if (panelList.length < 1) {
    return bot.sendMessage(msg.chat.id, "⚠️ Belum ada panel tersimpan.");
  }

  // tampilkan domain2 panel
  const buttons = panelList.map((p, i) => [{ text: p.domain.replace("https://", ""), callback_data: `choosePanel_${i}` }]);

  bot.sendMessage(msg.chat.id, "📡 Pilih panel yang ingin dicek:", {
    reply_markup: {
      inline_keyboard: buttons
    }
  });
});

// ─────────── Step 2: Ambil server dari panel ───────────
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;

  // pilih domain panel
  if (query.data.startsWith("choosePanel_")) {
    const index = parseInt(query.data.split("_")[1]);
    const panel = panelList[index];

    try {
      const res = await fetch(`${panel.domain}/api/application/servers`, {
        headers: {
          "Authorization": `Bearer ${panel.apikey}`,
          "Accept": "application/json",
          "Content-Type": "application/json"
        }
      });

      const data = await res.json();
      if (!data || !data.data) return bot.sendMessage(chatId, "⚠️ Gagal ambil data server.");

      // simpan ke state
      panel.cachedServers = data.data.map(s => ({
        id: s.attributes.id,
        name: s.attributes.name,
        identifier: s.attributes.identifier
      }));

      sendServerPage(chatId, panel, 1, query.id);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, "❌ Error ambil server dari panel.");
    }
  }

  // pagination server
  if (query.data.startsWith("pageServer_")) {
    const [_, domain, page] = query.data.split("_");
    const panel = panelList.find(p => p.domain === domain);
    sendServerPage(chatId, panel, parseInt(page), query.id);
  }

  // detail server
  if (query.data.startsWith("serverDetail_")) {
    const [_, domain, id] = query.data.split("_");
    const panel = panelList.find(p => p.domain === domain);
    const srv = panel.cachedServers.find(s => s.id.toString() === id);

    bot.answerCallbackQuery(query.id);
    bot.sendMessage(chatId, `🖥 Detail Server\n\n📌 Name: ${srv.name}\n🆔 ID: ${srv.id}\n🔑 Identifier: ${srv.identifier}\n🌍 Panel: ${domain}`);
  }
});

// ─────────── Helper: paginate server list ───────────
function sendServerPage(chatId, panel, page, queryId) {
  const perPage = 20;
  const start = (page - 1) * perPage;
  const end = start + perPage;
  const total = panel.cachedServers.length;
  const maxPage = Math.ceil(total / perPage);

  const servers = panel.cachedServers.slice(start, end);
  let text = `🖥 Server List - ${panel.domain}\nHal ${page}/${maxPage}\n\n`;
  servers.forEach((s, i) => {
    text += `${start + i + 1}. ${s.name}\n`;
  });

  // tombol angka buat detail
  const buttons = servers.map(s => [{ text: s.name.substring(0, 15), callback_data: `serverDetail_${panel.domain}_${s.id}` }]);

  // navigasi
  const nav = [];
  if (page > 1) nav.push({ text: "⬅️ Prev", callback_data: `pageServer_${panel.domain}_${page - 1}` });
  if (page < maxPage) nav.push({ text: "Next ➡️", callback_data: `pageServer_${panel.domain}_${page + 1}` });
  if (nav.length) buttons.push(nav);

  bot.answerCallbackQuery(queryId);
  bot.sendMessage(chatId, text, {
    reply_markup: {
      inline_keyboard: buttons
    }
  });
}
// Command hapus server
bot.onText(/^\/delpanel$/, async (msg) => {
    const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Lu bukan owner, gabisa akses command ini.");
  }

  if (panelList.length < 1) {
    return bot.sendMessage(msg.chat.id, "⚠️ Tidak ada panel yang tersimpan.");
  }

  const buttons = panelList.map((p, i) => [
    { text: p.domain.replace("https://", ""), callback_data: `choosePanelDelSrv_${i}` }
  ]);

  bot.sendMessage(msg.chat.id, "🔎 Pilih panel untuk hapus server:", {
    reply_markup: { inline_keyboard: buttons }
  });
});

// Callback pilih panel
bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;

  if (query.data.startsWith("choosePanelDelSrv_")) {
    const index = parseInt(query.data.split("_")[1]);
    const panel = panelList[index];

    try {
      const res = await fetch(`${panel.domain}/api/application/servers`, {
        headers: { "Authorization": `Bearer ${panel.apikey}`, "Content-Type": "application/json", "Accept": "application/json" }
      });
      const data = await res.json();

      if (!data.data || data.data.length === 0) {
        return bot.sendMessage(chatId, "⚠️ Tidak ada server di panel ini.");
      }

      // simpan sementara biar ga bingung pas callback
      cacheUser[chatId] = { panel, servers: data.data };

      const buttons = data.data.slice(0, 20).map((srv, i) => [
        { text: `${srv.attributes.name}`, callback_data: `chooseSrvDel_${i}` }
      ]);

      bot.sendMessage(chatId, `🗑 Pilih server yang mau dihapus di panel:\n🌍 ${panel.domain}`, {
        reply_markup: { inline_keyboard: buttons }
      });

    } catch (err) {
      bot.sendMessage(chatId, "❌ Gagal ambil data server dari panel.");
    }
  }

  // pilih server untuk dihapus
  if (query.data.startsWith("chooseSrvDel_")) {
    const index = parseInt(query.data.split("_")[1]);
    const { panel, servers } = cacheUser[chatId];
    const srv = servers[index];

    bot.sendMessage(chatId, `⚠️ Yakin mau hapus server ini?\n\n📌 ${srv.attributes.name}`, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: "✅ Ya", callback_data: `confirmSrvDel_${index}` },
            { text: "❌ Batal", callback_data: `cancelDelSrv` }
          ]
        ]
      }
    });
  }

  // konfirmasi hapus
  if (query.data.startsWith("confirmSrvDel_")) {
    const index = parseInt(query.data.split("_")[1]);
    const { panel, servers } = cacheUser[chatId];
    const srv = servers[index];

    try {
      await fetch(`${panel.domain}/api/application/servers/${srv.attributes.id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${panel.apikey}`, "Content-Type": "application/json", "Accept": "application/json" }
      });

      bot.sendMessage(chatId, `✅ Server **${srv.attributes.name}** berhasil dihapus.`);
    } catch (err) {
      bot.sendMessage(chatId, "❌ Gagal menghapus server.");
    }
  }

  if (query.data === "cancelDelSrv") {
    bot.sendMessage(chatId, "❌ Dibatalkan.");
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// cekid
bot.onText(/\/cekid/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const id = msg.from.id;
    const owner = '6924389613'; // Ganti dengan ID pemilik bot 
    const text12 = `Hi @${sender} 👋
    
👤 From ${id}
  └🙋🏽 kamu
  
 ID Telegram Anda: ${id}
 Full Name Anda : @${sender}

Itu adalah id telegram anda 🤗
 Developer : @ibradecode`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Owner', url: 'https://t.me/ibradecode' }, { text: 'Owner', url: 'https://t.me/ibradecode' }],
                [{ text: 'Owner', url: 'https://t.me/ibradecode' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// createadmin
bot.onText(/\/adp (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/ibradecode' }
          ]
        ]
      }
    });
    return;
  }
  const commandParams = match[1].split(',');
  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();
  if (commandParams.length < 2) {
    bot.sendMessage(chatId, 'Format Salah! Penggunaan: /adp namapanel,idtele');
    return;
  }
  const password = panelName + `${rand3}`;
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${plta}`
      },
      body: JSON.stringify({
        email: `${panelName}@ibra.biz.id`,
        username: panelName,
        first_name: panelName,
        last_name: "Memb",
        language: "en",
        root_admin: true,
        password: password
      })
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: user
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
    bot.sendMessage(telegramId,`
╭──❏「 INFO DATA ADMIN PANEL 」❏
┃➥  Login : ${domain}
┃➥  Username : ${user.username}
┃➥  Password : ${password} 
┗━━━━━[ XMSBRA BOT ]━━━━
➡️ Rules : 
• Jangan Curi Sc
• Jangan Buka Panel Orang
• Jangan Ddos Server
• Kalo jualan sensor domainnya
• Jangan Bagi² Panel Free
• Jangan Jualan Admin Panel Kecuali Pt Gw !!

NGEYEL? KICK NO REFF NO DRAMA
Jangan Lupa Bilang Done Jika Sudah Di CEK
==============================
    `);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, 'Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti.');
  }
});
fs.readFile(adminfile, (err, data) => {
  if (err) {
    console.error(err);
  } else {
    adminIDs = JSON.parse(data);
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listsrv

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listadmin
bot.onText(/\/listadmin/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));
    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah Hanya Untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'HUBUNGI ADMIN', url: 'https://t.me/ibradecode' }
                    ]
                ]
            }
        });
        return;
    }
    let page = '1';
    try {
        let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${plta}`
            }
        });
        let res = await f.json();
        let users = res.data;
        let messageText = "Berikut list admin :\n\n";
        for (let user of users) {
            let u = user.attributes;
            if (u.root_admin) {
                messageText += `🆔 ID: ${u.id} - 🌟 Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
                messageText += `${u.username}\n`;
                messageText += `${u.first_name} ${u.last_name}\n\n`;
                messageText += 'By Ruztan';
            }
        }
        messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
        messageText += `Total Admin: ${res.meta.pagination.count}`;
        const keyboard = [
            [
                { text: 'BACK', callback_data: JSON.stringify({ action: 'back', page: parseInt(res.meta.pagination.current_page) - 1 }) },
                { text: 'NEXT', callback_data: JSON.stringify({ action: 'next', page: parseInt(res.meta.pagination.current_page) + 1 }) }
            ]
        ];
        bot.sendMessage(chatId, messageText, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
        //▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// batas akhir
    } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
    }
});
  bot.onText(/\/panel/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '6924389613'; // Ganti dengan ID pemilik bot 
    const text12 = `*Hi @${sender} 👋*
    
CARA BIKIN PANEL 

contoh : /unli ibra,6924389613

UNTUK ID TELE NYA BISA CEK KETIK /cekid 

𝗕𝘂𝘆 𝗣𝗿𝗲𝗺? 𝗕𝘂𝘆 𝗔𝗱𝗺𝗶𝗻𝗣 & 𝗣𝘁 𝗣𝗮𝗻𝗲𝗹? 𝗕𝘂𝘆 𝗦𝗰? 𝗣𝘃 (@ibradecode)`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/ibradecode' }, { text: '👤 Buy Admin', url: 'https://t.me/ibradecode' }],
                [{ text: '🇲🇨 Buy Vps', url: 'https://t.me/ibradecode' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});      
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});