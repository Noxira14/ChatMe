
const config = {
  token: '8321611789:AAF9wGyKnptSyRdDGeVQv9D-Qc3bhTLvo6E',
  adminId: '6924389613', 
  pp: 'https://files.catbox.moe/7l5fvh.jpg',
urladmin: 'https://t.me/ibradecode',
    //SERVER 1
  domain: 'https://rizzxd.storeid.my.id', // Isi dengan domain yang digunakan
  plta: 'ptla_6yinfI9gYn2NYTNQ1YkeC9YSYHrR4B27Nl5KCsqqX1S', // Isi dengan nilai plta yang sesuai
  pltc: 'ptlc_C9cTqFnciShlbcGeRnlKU8iToSidLUmVF0B9as3aZts', // Isi dengan nilai pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = config;