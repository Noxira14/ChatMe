const config = require('../config/config');
const logger = require('../utils/logger');
const authMiddleware = require('../middleware/auth');
const panelService = require('../services/panelService');
const Helpers = require('../utils/helpers');

class UserCommands {
  /**
   * Start command
   */
  static async start(msg) {
    try {
      const userInfo = authMiddleware.getUserInfo(msg.from.id);
      const username = msg.from.first_name || msg.from.username || 'User';

      let welcomeText = config.messages.welcome.replace('CPanel Bot', 'CPanel Bot');
      
      // Add user status
      if (userInfo.isOwner) {
        welcomeText += `\n\n👑 *Status:* Owner`;
      } else if (userInfo.isAdmin) {
        welcomeText += `\n\n🛡️ *Status:* Admin`;
      } else if (userInfo.isPremium) {
        welcomeText += `\n\n⭐ *Status:* Premium User`;
      } else {
        welcomeText += `\n\n👤 *Status:* Regular User`;
      }

      welcomeText += `\n\n👋 Halo ${Helpers.escapeMarkdown(username)}!`;

      return {
        text: welcomeText,
        options: {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📋 Help', callback_data: 'help' },
                { text: '📊 Status', callback_data: 'status' }
              ],
              [
                { text: '🌐 Panel', callback_data: 'panel' },
                { text: '👤 Profile', callback_data: 'profile' }
              ]
            ]
          }
        }
      };

    } catch (error) {
      logger.error('Error in start command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Help command
   */
  static async help(msg) {
    try {
      const userInfo = authMiddleware.getUserInfo(msg.from.id);

      let helpText = `📋 *Daftar Perintah*\n\n`;

      // Basic commands for all users
      helpText += `👤 *Perintah Umum:*\n`;
      helpText += `• \`/start\` - Mulai bot\n`;
      helpText += `• \`/help\` - Tampilkan bantuan\n`;
      helpText += `• \`/cekid\` - Cek ID Telegram\n`;
      helpText += `• \`/panel\` - Menu panel\n\n`;

      // Premium commands
      if (userInfo.isPremium) {
        helpText += `⭐ *Perintah Premium:*\n`;
        helpText += `• \`/buatpanel <data>\` - Buat panel baru\n`;
        helpText += `• \`/listpanel\` - Lihat daftar panel\n`;
        helpText += `• \`/delpanel\` - Hapus panel\n\n`;
      }

      // Admin commands
      if (userInfo.isAdmin) {
        helpText += `🛡️ *Perintah Admin:*\n`;
        helpText += `• \`/addsrv <nama> <domain> <plta> <pltc>\` - Tambah server\n`;
        helpText += `• \`/listsrv\` - Lihat daftar server\n`;
        helpText += `• \`/delsrv <nama>\` - Hapus server\n`;
        helpText += `• \`/srvinfo <nama>\` - Info server\n`;
        helpText += `• \`/addprem <userid>\` - Tambah premium\n`;
        helpText += `• \`/delprem <userid>\` - Hapus premium\n`;
        helpText += `• \`/listadmin\` - Lihat daftar admin\n\n`;
      }

      // Owner commands
      if (userInfo.isOwner) {
        helpText += `👑 *Perintah Owner:*\n`;
        helpText += `• \`/addowner <userid>\` - Tambah admin\n`;
        helpText += `• \`/delowner <userid>\` - Hapus admin\n`;
        helpText += `• \`/clearserver\` - Bersihkan semua server\n`;
        helpText += `• \`/stats\` - Statistik bot\n\n`;
      }

      helpText += `💡 *Tips:*\n`;
      helpText += `• Gunakan \`/cekid\` untuk mendapatkan ID Telegram Anda\n`;
      helpText += `• Semua perintah case-sensitive\n`;
      helpText += `• Untuk bantuan lebih lanjut, hubungi admin`;

      return {
        text: helpText,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in help command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Check ID command
   */
  static async checkId(msg) {
    try {
      const userInfo = authMiddleware.getUserInfo(msg.from.id);
      
      let text = `🆔 *Informasi Akun*\n\n`;
      text += `👤 *User ID:* \`${msg.from.id}\`\n`;
      text += `📝 *Username:* ${msg.from.username ? `@${msg.from.username}` : 'Tidak ada'}\n`;
      text += `👋 *Nama:* ${msg.from.first_name || 'Tidak ada'}`;
      
      if (msg.from.last_name) {
        text += ` ${msg.from.last_name}`;
      }
      
      text += `\n💬 *Chat ID:* \`${msg.chat.id}\`\n`;
      text += `🏷️ *Chat Type:* ${msg.chat.type}\n\n`;
      
      text += `🎭 *Status:*\n`;
      if (userInfo.isOwner) {
        text += `• 👑 Owner\n`;
      }
      if (userInfo.isAdmin) {
        text += `• 🛡️ Admin\n`;
      }
      if (userInfo.isPremium) {
        text += `• ⭐ Premium User\n`;
      }
      if (!userInfo.isOwner && !userInfo.isAdmin && !userInfo.isPremium) {
        text += `• 👤 Regular User\n`;
      }

      return {
        text,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in checkId command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Create panel command
   */
  static async createPanel(msg, match) {
    try {
      const params = match[1].split(',').map(p => p.trim());
      
      if (params.length < 4) {
        return {
          text: `❌ *Format salah!*\n\n` +
                `Gunakan: \`/buatpanel <username>,<email>,<nama_depan>,<nama_belakang>,<server>\`\n\n` +
                `Contoh:\n\`/buatpanel john123,john@email.com,John,Doe,server1\``
        };
      }

      const [username, email, firstName, lastName, serverName] = params;

      // Validate email
      if (!Helpers.isValidEmail(email)) {
        return { text: '❌ Format email tidak valid!' };
      }

      // Get server
      const server = panelService.getServer(serverName || 'default');
      if (!server) {
        const servers = panelService.getAllServers();
        if (servers.length === 0) {
          return { text: '❌ Tidak ada server yang tersedia!' };
        }
        
        let serverList = '❌ Server tidak ditemukan!\n\n📋 *Server yang tersedia:*\n';
        servers.forEach((srv, index) => {
          serverList += `${index + 1}. \`${srv.name}\`\n`;
        });
        
        return { text: serverList };
      }

      // Send processing message
      const processingMsg = await msg.reply(config.messages.processing);

      // Create panel
      const result = await panelService.createPanel(server, {
        username,
        email,
        firstName,
        lastName
      });

      // Delete processing message
      try {
        await processingMsg.delete();
      } catch (e) {
        // Ignore if can't delete
      }

      if (result.success) {
        const text = `✅ *Panel berhasil dibuat!*\n\n` +
                     `👤 *Detail Akun:*\n` +
                     `• Username: \`${result.data.user.username}\`\n` +
                     `• Email: \`${result.data.user.email}\`\n` +
                     `• Password: \`${result.data.user.password}\`\n\n` +
                     `🌐 *Login URL:* ${result.data.loginUrl}\n` +
                     `⏱️ *Waktu Proses:* ${result.data.responseTime}ms\n\n` +
                     `⚠️ *Simpan informasi ini dengan aman!*`;

        return {
          text,
          options: { parse_mode: 'Markdown' }
        };
      } else {
        return {
          text: `❌ *Gagal membuat panel!*\n\nError: ${result.error}`
        };
      }

    } catch (error) {
      logger.error('Error in createPanel command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Panel menu command
   */
  static async panelMenu(msg) {
    try {
      const userInfo = authMiddleware.getUserInfo(msg.from.id);
      const servers = panelService.getAllServers();

      let text = `🌐 *Panel Management*\n\n`;
      
      if (servers.length === 0) {
        text += `❌ Tidak ada server yang tersedia.\n\n`;
        if (userInfo.isAdmin) {
          text += `Gunakan \`/addsrv\` untuk menambah server.`;
        } else {
          text += `Hubungi admin untuk menambah server.`;
        }
        
        return { text, options: { parse_mode: 'Markdown' } };
      }

      text += `📊 *Status Server (${servers.length}):*\n`;
      servers.forEach((server, index) => {
        text += `${index + 1}. ${server.name} - \`${server.status}\`\n`;
      });

      const keyboard = [];

      if (userInfo.isPremium) {
        keyboard.push([
          { text: '➕ Buat Panel', callback_data: 'create_panel' },
          { text: '📋 List Panel', callback_data: 'list_panels' }
        ]);
      }

      if (userInfo.isAdmin) {
        keyboard.push([
          { text: '🛠️ Kelola Server', callback_data: 'manage_servers' },
          { text: '👥 Kelola User', callback_data: 'manage_users' }
        ]);
      }

      keyboard.push([
        { text: '🔄 Refresh', callback_data: 'panel_refresh' },
        { text: '❌ Tutup', callback_data: 'close' }
      ]);

      return {
        text,
        options: {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: keyboard
          }
        }
      };

    } catch (error) {
      logger.error('Error in panelMenu command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Bot status command
   */
  static async status(msg) {
    try {
      const runtime = Helpers.getRuntime();
      const memUsage = process.memoryUsage();
      const servers = panelService.getAllServers();

      const text = `📊 *Status Bot*\n\n` +
                   `🟢 *Status:* Online\n` +
                   `⏱️ *Runtime:* ${runtime}\n` +
                   `🖥️ *Memory:* ${Helpers.formatBytes(memUsage.heapUsed)}\n` +
                   `🌐 *Servers:* ${servers.length} aktif\n` +
                   `📅 *Last Update:* ${new Date().toLocaleString('id-ID')}`;

      return {
        text,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in status command', error);
      return { text: config.messages.error };
    }
  }
}

module.exports = UserCommands;
