const config = require('../config/config');
const logger = require('../utils/logger');
const authMiddleware = require('../middleware/auth');
const authenticationMiddleware = require('../middleware/authentication');
const groupAccessMiddleware = require('../middleware/groupAccess');
const securityService = require('../services/securityService');
const cleanupService = require('../services/cleanupService');
const similarityMatcher = require('../utils/similarity');
const Helpers = require('../utils/helpers');

class NewCommands {
  /**
   * Authentication command
   */
  static async authenticate(msg, match) {
    try {
      const userId = msg.from.id;
      const password = match[1].trim();

      if (!password) {
        return {
          text: '❌ *Format salah!*\n\nGunakan: `/auth <password>`',
          options: { parse_mode: 'Markdown' }
        };
      }

      const isValid = await authenticationMiddleware.authenticateUser(userId, password);
      
      if (isValid) {
        return {
          text: '✅ *VERIFIKASI BERHASIL!*\n\nSelamat datang! Anda sekarang dapat menggunakan bot.\n\nKetik `/help` untuk melihat perintah yang tersedia.',
          options: { parse_mode: 'Markdown' }
        };
      } else {
        return {
          text: '❌ *PASSWORD SALAH!*\n\nSilakan coba lagi dengan password yang benar.\n\nFormat: `/auth <password>`',
          options: { parse_mode: 'Markdown' }
        };
      }

    } catch (error) {
      logger.error('Error in authenticate command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Add group access command
   */
  static async addGroupAccess(msg, match) {
    try {
      const params = match[1].split(' ');
      
      if (params.length < 2) {
        return {
          text: '❌ *Format salah!*\n\n' +
                'Gunakan: `/addgc <group_id> <type>`\n\n' +
                'Type: reseller, admin, owner, developer\n\n' +
                'Contoh: `/addgc -1001234567890 reseller`'
        };
      }

      const [groupId, type] = params;
      const validTypes = ['reseller', 'admin', 'owner', 'developer'];

      if (!validTypes.includes(type)) {
        return {
          text: `❌ *Tipe tidak valid!*\n\nTipe yang tersedia: ${validTypes.join(', ')}`
        };
      }

      await groupAccessMiddleware.addGroupAccess(groupId, type);

      return {
        text: `✅ *Akses grup berhasil ditambahkan!*\n\n` +
              `🆔 *Group ID:* \`${groupId}\`\n` +
              `🏷️ *Tipe:* ${type}\n` +
              `📅 *Ditambahkan:* ${new Date().toLocaleString('id-ID')}`,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in addGroupAccess command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Remove group access command
   */
  static async removeGroupAccess(msg, match) {
    try {
      const groupId = match[1].trim();

      if (!groupId) {
        return {
          text: '❌ *Format salah!*\n\nGunakan: `/delgc <group_id>`'
        };
      }

      const removed = await groupAccessMiddleware.removeGroupAccess(groupId);

      if (removed) {
        return {
          text: `✅ *Akses grup berhasil dihapus!*\n\n🆔 *Group ID:* \`${groupId}\``,
          options: { parse_mode: 'Markdown' }
        };
      } else {
        return {
          text: `❌ *Grup tidak ditemukan!*\n\n🆔 *Group ID:* \`${groupId}\``
        };
      }

    } catch (error) {
      logger.error('Error in removeGroupAccess command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * List group access command
   */
  static async listGroupAccess(msg) {
    try {
      const groupAccesses = groupAccessMiddleware.getAllGroupAccesses();

      if (groupAccesses.length === 0) {
        return {
          text: '📋 *Daftar Akses Grup*\n\nTidak ada grup yang memiliki akses khusus.'
        };
      }

      let text = `📋 *Daftar Akses Grup (${groupAccesses.length})*\n\n`;

      groupAccesses.forEach((access, index) => {
        text += `${index + 1}. **${access.type.toUpperCase()}**\n`;
        text += `   • ID: \`${access.groupId}\`\n`;
        text += `   • Ditambahkan: ${new Date(access.addedAt).toLocaleString('id-ID')}\n\n`;
      });

      return {
        text,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in listGroupAccess command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Ban user command
   */
  static async banUser(msg, match) {
    try {
      const userId = match[1].trim();

      if (!userId) {
        return {
          text: '❌ *Format salah!*\n\nGunakan: `/ban <user_id>`'
        };
      }

      await authenticationMiddleware.banUser(userId);

      return {
        text: `✅ *User berhasil dibanned!*\n\n👤 *User ID:* \`${userId}\``,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in banUser command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Unban user command
   */
  static async unbanUser(msg, match) {
    try {
      const userId = match[1].trim();

      if (!userId) {
        return {
          text: '❌ *Format salah!*\n\nGunakan: `/unban <user_id>`'
        };
      }

      const removed = await authenticationMiddleware.unbanUser(userId);

      if (removed) {
        return {
          text: `✅ *User berhasil di-unban!*\n\n👤 *User ID:* \`${userId}\``,
          options: { parse_mode: 'Markdown' }
        };
      } else {
        return {
          text: `❌ *User tidak ditemukan dalam daftar banned!*\n\n👤 *User ID:* \`${userId}\``
        };
      }

    } catch (error) {
      logger.error('Error in unbanUser command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Maintenance mode command
   */
  static async maintenanceMode(msg, match) {
    try {
      const action = match[1]?.trim().toLowerCase();

      if (!action || !['on', 'off', 'status'].includes(action)) {
        return {
          text: '❌ *Format salah!*\n\n' +
                'Gunakan: `/maintenance <on|off|status>`\n\n' +
                'Contoh:\n' +
                '• `/maintenance on` - Aktifkan maintenance\n' +
                '• `/maintenance off` - Matikan maintenance\n' +
                '• `/maintenance status` - Cek status'
        };
      }

      if (action === 'status') {
        const stats = authenticationMiddleware.getStats();
        return {
          text: `🔧 *Status Maintenance*\n\n` +
                `Status: ${stats.maintenanceMode ? '🔴 AKTIF' : '🟢 TIDAK AKTIF'}\n` +
                `User terautentikasi: ${stats.authenticated}\n` +
                `User terbanned: ${stats.banned}`,
          options: { parse_mode: 'Markdown' }
        };
      }

      const enabled = action === 'on';
      await authenticationMiddleware.setMaintenanceMode(enabled);

      return {
        text: `${enabled ? '🔴' : '🟢'} *Maintenance Mode ${enabled ? 'DIAKTIFKAN' : 'DIMATIKAN'}*\n\n` +
              `${enabled ? 'Bot sekarang dalam mode maintenance.' : 'Bot kembali normal.'}`,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in maintenanceMode command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Security panel command
   */
  static async securityPanel(msg, match) {
    try {
      const action = match[1]?.trim().toLowerCase();

      if (!action || !['start', 'stop', 'status', 'alerts'].includes(action)) {
        return {
          text: '❌ *Format salah!*\n\n' +
                'Gunakan: `/security_panel <start|stop|status|alerts>`\n\n' +
                'Contoh:\n' +
                '• `/security_panel start` - Mulai monitoring\n' +
                '• `/security_panel stop` - Hentikan monitoring\n' +
                '• `/security_panel status` - Cek status\n' +
                '• `/security_panel alerts` - Lihat alerts'
        };
      }

      if (action === 'start') {
        await securityService.startMonitoring();
        return {
          text: '🛡️ *Security Monitoring DIAKTIFKAN*\n\n' +
                'Bot akan memantau aktivitas mencurigakan di panel.\n' +
                'Notifikasi akan dikirim jika ada aktivitas tidak normal.',
          options: { parse_mode: 'Markdown' }
        };
      }

      if (action === 'stop') {
        await securityService.stopMonitoring();
        return {
          text: '🛡️ *Security Monitoring DIMATIKAN*\n\n' +
                'Monitoring keamanan telah dihentikan.',
          options: { parse_mode: 'Markdown' }
        };
      }

      if (action === 'status') {
        const stats = securityService.getSecurityStats();
        return {
          text: `🛡️ *Status Security Panel*\n\n` +
                `Monitoring: ${stats.monitoring ? '🟢 AKTIF' : '🔴 TIDAK AKTIF'}\n` +
                `Trusted Users: ${stats.trustedUsers}\n` +
                `Total Alerts: ${stats.totalAlerts}\n` +
                `Alerts 24h: ${stats.recentAlerts}\n\n` +
                `📊 *Alert Types:*\n` +
                Object.entries(stats.alertsByType).map(([type, count]) => 
                  `• ${type}: ${count}`
                ).join('\n'),
          options: { parse_mode: 'Markdown' }
        };
      }

      if (action === 'alerts') {
        const alerts = securityService.getRecentAlerts(5);
        
        if (alerts.length === 0) {
          return {
            text: '🛡️ *Security Alerts*\n\nTidak ada alert keamanan terbaru.',
            options: { parse_mode: 'Markdown' }
          };
        }

        let text = `🛡️ *Security Alerts Terbaru*\n\n`;
        
        alerts.forEach((alert, index) => {
          text += `${index + 1}. **${alert.type.toUpperCase()}**\n`;
          text += `   • Server: ${alert.data.server}\n`;
          text += `   • User: ${alert.data.username}\n`;
          text += `   • IP: ${alert.data.ip}\n`;
          text += `   • Waktu: ${new Date(alert.timestamp).toLocaleString('id-ID')}\n\n`;
        });

        return {
          text,
          options: { parse_mode: 'Markdown' }
        };
      }

    } catch (error) {
      logger.error('Error in securityPanel command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Cleanup command
   */
  static async cleanupCommand(msg, match) {
    try {
      const action = match[1]?.trim().toLowerCase();

      if (!action || !['start', 'stop', 'status', 'run', 'history'].includes(action)) {
        return {
          text: '❌ *Format salah!*\n\n' +
                'Gunakan: `/cleanup <start|stop|status|run|history>`\n\n' +
                'Contoh:\n' +
                '• `/cleanup start` - Mulai auto cleanup\n' +
                '• `/cleanup stop` - Hentikan auto cleanup\n' +
                '• `/cleanup run` - Jalankan cleanup manual\n' +
                '• `/cleanup status` - Cek status\n' +
                '• `/cleanup history` - Lihat riwayat'
        };
      }

      if (action === 'start') {
        cleanupService.startAutoCleanup();
        return {
          text: '🧹 *Auto Cleanup DIAKTIFKAN*\n\n' +
                'Bot akan melakukan pembersihan otomatis setiap 5 jam.\n' +
                'Server yang tidak aktif >2 hari akan dilaporkan.',
          options: { parse_mode: 'Markdown' }
        };
      }

      if (action === 'stop') {
        cleanupService.stopAutoCleanup();
        return {
          text: '🧹 *Auto Cleanup DIMATIKAN*\n\n' +
                'Pembersihan otomatis telah dihentikan.',
          options: { parse_mode: 'Markdown' }
        };
      }

      if (action === 'run') {
        const processingMsg = await msg.reply('🧹 Menjalankan pembersihan...');
        
        const result = await cleanupService.triggerManualCleanup();
        
        try {
          await processingMsg.delete();
        } catch (e) {
          // Ignore if can't delete
        }

        if (result) {
          return {
            text: `🧹 *Pembersihan Selesai*\n\n` +
                  `📊 *Hasil:*\n` +
                  `• Server diperiksa: ${result.serversChecked}\n` +
                  `• Server tidak aktif: ${result.inactiveFound}\n` +
                  `• Waktu: ${result.duration}ms\n\n` +
                  `${result.inactiveFound > 0 ? '⚠️ Gunakan `/cleanup_action` untuk mengelola server tidak aktif.' : '✅ Semua server aktif!'}`,
            options: { parse_mode: 'Markdown' }
          };
        } else {
          return { text: '❌ Gagal menjalankan pembersihan!' };
        }
      }

      if (action === 'status') {
        const stats = cleanupService.getCleanupStats();
        return {
          text: `🧹 *Status Cleanup*\n\n` +
                `Auto Cleanup: ${stats.autoCleanup ? '🟢 AKTIF' : '🔴 TIDAK AKTIF'}\n` +
                `Last Cleanup: ${stats.lastCleanup ? new Date(stats.lastCleanup).toLocaleString('id-ID') : 'Belum pernah'}\n` +
                `Total Cleanup: ${stats.totalCleanups}\n` +
                `Cleanup 24h: ${stats.recentCleanups}\n` +
                `Rata-rata Inactive: ${stats.averageInactive}`,
          options: { parse_mode: 'Markdown' }
        };
      }

      if (action === 'history') {
        const history = cleanupService.getRecentCleanups(5);
        
        if (history.length === 0) {
          return {
            text: '🧹 *Riwayat Cleanup*\n\nBelum ada riwayat cleanup.',
            options: { parse_mode: 'Markdown' }
          };
        }

        let text = `🧹 *Riwayat Cleanup Terbaru*\n\n`;
        
        history.forEach((cleanup, index) => {
          text += `${index + 1}. ${new Date(cleanup.timestamp).toLocaleString('id-ID')}\n`;
          text += `   • Server: ${cleanup.serversChecked}\n`;
          text += `   • Inactive: ${cleanup.inactiveFound}\n`;
          text += `   • Durasi: ${cleanup.duration}ms\n\n`;
        });

        return {
          text,
          options: { parse_mode: 'Markdown' }
        };
      }

    } catch (error) {
      logger.error('Error in cleanupCommand', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Join group command
   */
  static async joinGroup(msg, match) {
    try {
      const inviteLink = match[1]?.trim();

      if (!inviteLink) {
        return {
          text: '❌ *Format salah!*\n\nGunakan: `/joingc <invite_link>`\n\nContoh: `/joingc https://t.me/+abcdefghijk`'
        };
      }

      // This would be implemented in the bot class to actually join the group
      return {
        text: `🔄 *Mencoba bergabung ke grup...*\n\n` +
              `🔗 *Link:* ${inviteLink}\n\n` +
              `⏳ Mohon tunggu...`,
        options: { parse_mode: 'Markdown' }
      };

    } catch (error) {
      logger.error('Error in joinGroup command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Process command similarity
   */
  static processCommandSimilarity(inputCommand) {
    return similarityMatcher.processSimilarity(inputCommand);
  }
}

module.exports = NewCommands;
