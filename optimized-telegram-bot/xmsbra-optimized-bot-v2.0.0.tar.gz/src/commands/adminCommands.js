const config = require('../config/config');
const logger = require('../utils/logger');
const authMiddleware = require('../middleware/auth');
const panelService = require('../services/panelService');
const Helpers = require('../utils/helpers');

class AdminCommands {
  /**
   * Add server command
   */
  static async addServer(msg, match) {
    try {
      const params = match[1].split(' ');
      if (params.length < 4) {
        return {
          text: `❌ *Format salah!*\n\n` +
                `Gunakan: \`/addsrv <nama> <domain> <plta> <pltc>\`\n\n` +
                `Contoh:\n\`/addsrv server1 https://panel.example.com ptla_xxx ptlc_xxx\``
        };
      }

      const [name, domain, plta, pltc] = params;

      // Validate domain
      if (!Helpers.isValidUrl(domain)) {
        return { text: '❌ Domain tidak valid!' };
      }

      // Check if server already exists
      if (panelService.getServer(name)) {
        return { text: `❌ Server dengan nama "${name}" sudah ada!` };
      }

      const server = await panelService.addServer(name, {
        domain,
        plta,
        pltc,
        location: config.server.location,
        eggs: config.server.eggs
      });

      return {
        text: `✅ *Server berhasil ditambahkan!*\n\n` +
              `📋 *Detail Server:*\n` +
              `• Nama: \`${server.name}\`\n` +
              `• Domain: \`${server.domain}\`\n` +
              `• Location: \`${server.location}\`\n` +
              `• Eggs: \`${server.eggs}\`\n` +
              `• Status: \`${server.status}\`\n` +
              `• Dibuat: \`${new Date(server.createdAt).toLocaleString('id-ID')}\``
      };

    } catch (error) {
      logger.error('Error in addServer command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * List servers command
   */
  static async listServers(msg) {
    try {
      const servers = panelService.getAllServers();

      if (servers.length === 0) {
        return { text: '📋 Tidak ada server yang terdaftar.' };
      }

      let text = `📋 *Daftar Server (${servers.length})*\n\n`;

      servers.forEach((server, index) => {
        text += `${index + 1}. *${server.name}*\n`;
        text += `   • Domain: \`${server.domain}\`\n`;
        text += `   • Status: \`${server.status}\`\n`;
        text += `   • Dibuat: \`${new Date(server.createdAt).toLocaleString('id-ID')}\`\n\n`;
      });

      return { text };

    } catch (error) {
      logger.error('Error in listServers command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Delete server command
   */
  static async deleteServer(msg, match) {
    try {
      const serverName = match[1].trim();

      if (!panelService.getServer(serverName)) {
        return { text: `❌ Server "${serverName}" tidak ditemukan!` };
      }

      const success = await panelService.removeServer(serverName);

      if (success) {
        return {
          text: `✅ Server "${serverName}" berhasil dihapus!`
        };
      } else {
        return { text: '❌ Gagal menghapus server!' };
      }

    } catch (error) {
      logger.error('Error in deleteServer command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Server info command
   */
  static async serverInfo(msg, match) {
    try {
      const serverName = match[1].trim();
      const server = panelService.getServer(serverName);

      if (!server) {
        return { text: `❌ Server "${serverName}" tidak ditemukan!` };
      }

      const text = `📊 *Informasi Server: ${server.name}*\n\n` +
                   `🌐 *Domain:* \`${server.domain}\`\n` +
                   `📍 *Location:* \`${server.location}\`\n` +
                   `🥚 *Eggs:* \`${server.eggs}\`\n` +
                   `📊 *Status:* \`${server.status}\`\n` +
                   `📅 *Dibuat:* \`${new Date(server.createdAt).toLocaleString('id-ID')}\`\n` +
                   (server.updatedAt ? `🔄 *Diupdate:* \`${new Date(server.updatedAt).toLocaleString('id-ID')}\`\n` : '') +
                   `\n🔗 *Panel URL:* ${server.domain}`;

      return { text };

    } catch (error) {
      logger.error('Error in serverInfo command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Add premium user command
   */
  static async addPremium(msg, match) {
    try {
      const userId = match[1].trim();

      if (!userId || isNaN(userId)) {
        return { text: '❌ ID user tidak valid!' };
      }

      await authMiddleware.addPremium(userId);

      return {
        text: `✅ User dengan ID \`${userId}\` berhasil ditambahkan ke premium!`
      };

    } catch (error) {
      logger.error('Error in addPremium command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Remove premium user command
   */
  static async removePremium(msg, match) {
    try {
      const userId = match[1].trim();

      if (!userId || isNaN(userId)) {
        return { text: '❌ ID user tidak valid!' };
      }

      await authMiddleware.removePremium(userId);

      return {
        text: `✅ User dengan ID \`${userId}\` berhasil dihapus dari premium!`
      };

    } catch (error) {
      logger.error('Error in removePremium command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Add admin user command
   */
  static async addAdmin(msg, match) {
    try {
      const userId = match[1].trim();

      if (!userId || isNaN(userId)) {
        return { text: '❌ ID user tidak valid!' };
      }

      await authMiddleware.addAdmin(userId);

      return {
        text: `✅ User dengan ID \`${userId}\` berhasil ditambahkan sebagai admin!`
      };

    } catch (error) {
      logger.error('Error in addAdmin command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Remove admin user command
   */
  static async removeAdmin(msg, match) {
    try {
      const userId = match[1].trim();

      if (!userId || isNaN(userId)) {
        return { text: '❌ ID user tidak valid!' };
      }

      if (userId === config.bot.adminId) {
        return { text: '❌ Tidak dapat menghapus owner dari admin!' };
      }

      await authMiddleware.removeAdmin(userId);

      return {
        text: `✅ User dengan ID \`${userId}\` berhasil dihapus dari admin!`
      };

    } catch (error) {
      logger.error('Error in removeAdmin command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * List admin users command
   */
  static async listAdmins(msg) {
    try {
      const admins = authMiddleware.getAdminUsers();
      const premiums = authMiddleware.getPremiumUsers();

      let text = `👥 *Daftar User*\n\n`;
      
      text += `👑 *Owner:* \`${config.bot.adminId}\`\n\n`;
      
      if (admins.length > 0) {
        text += `🛡️ *Admin Users (${admins.length}):*\n`;
        admins.forEach((adminId, index) => {
          text += `${index + 1}. \`${adminId}\`\n`;
        });
        text += '\n';
      }

      if (premiums.length > 0) {
        text += `⭐ *Premium Users (${premiums.length}):*\n`;
        premiums.forEach((premiumId, index) => {
          text += `${index + 1}. \`${premiumId}\`\n`;
        });
      }

      if (admins.length === 0 && premiums.length === 0) {
        text += 'Tidak ada admin atau premium user yang terdaftar.';
      }

      return { text };

    } catch (error) {
      logger.error('Error in listAdmins command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Clear server command
   */
  static async clearServer(msg) {
    try {
      const servers = panelService.getAllServers();

      if (servers.length === 0) {
        return { text: '❌ Tidak ada server yang terdaftar!' };
      }

      let text = `🧹 *Hasil Clear Server:*\n\n`;
      let totalDeleted = 0;

      for (const server of servers) {
        const result = await panelService.clearServer(server);
        
        if (result.success) {
          text += `✅ *${server.name}:* ${result.deletedUsers} users dihapus\n`;
          totalDeleted += result.deletedUsers;
        } else {
          text += `❌ *${server.name}:* ${result.error}\n`;
        }

        // Small delay between servers
        await Helpers.sleep(1000);
      }

      text += `\n📊 *Total:* ${totalDeleted} users dihapus dari ${servers.length} server`;

      return { text };

    } catch (error) {
      logger.error('Error in clearServer command', error);
      return { text: config.messages.error };
    }
  }

  /**
   * Bot statistics command
   */
  static async botStats(msg) {
    try {
      const servers = panelService.getAllServers();
      const admins = authMiddleware.getAdminUsers();
      const premiums = authMiddleware.getPremiumUsers();
      const runtime = Helpers.getRuntime();
      const memUsage = process.memoryUsage();

      const text = `📊 *Statistik Bot*\n\n` +
                   `⏱️ *Runtime:* ${runtime}\n` +
                   `🖥️ *Memory:* ${Helpers.formatBytes(memUsage.heapUsed)} / ${Helpers.formatBytes(memUsage.heapTotal)}\n` +
                   `🌐 *Servers:* ${servers.length}\n` +
                   `🛡️ *Admins:* ${admins.length}\n` +
                   `⭐ *Premium Users:* ${premiums.length}\n` +
                   `📅 *Started:* ${new Date(Date.now() - process.uptime() * 1000).toLocaleString('id-ID')}`;

      return { text };

    } catch (error) {
      logger.error('Error in botStats command', error);
      return { text: config.messages.error };
    }
  }
}

module.exports = AdminCommands;
