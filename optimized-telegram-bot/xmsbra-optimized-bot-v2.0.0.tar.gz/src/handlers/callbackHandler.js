const config = require('../config/config');
const logger = require('../utils/logger');
const authMiddleware = require('../middleware/auth');
const panelService = require('../services/panelService');
const UserCommands = require('../commands/userCommands');
const AdminCommands = require('../commands/adminCommands');

class CallbackHandler {
  /**
   * Handle callback queries
   * @param {Object} bot - Telegram bot instance
   * @param {Object} query - Callback query
   */
  static async handle(bot, query) {
    try {
      const chatId = query.message.chat.id;
      const messageId = query.message.message_id;
      const data = query.data;
      const userId = query.from.id;

      logger.info(`Callback query: ${data} from user ${userId}`);

      let response;

      switch (data) {
        case 'help':
          response = await UserCommands.help({ from: query.from, chat: query.message.chat });
          break;

        case 'status':
          response = await UserCommands.status({ from: query.from, chat: query.message.chat });
          break;

        case 'panel':
          response = await UserCommands.panelMenu({ from: query.from, chat: query.message.chat });
          break;

        case 'profile':
          response = await UserCommands.checkId({ from: query.from, chat: query.message.chat });
          break;

        case 'create_panel':
          response = await this.handleCreatePanelMenu(userId);
          break;

        case 'list_panels':
          response = await this.handleListPanels(userId);
          break;

        case 'manage_servers':
          response = await this.handleManageServers(userId);
          break;

        case 'manage_users':
          response = await this.handleManageUsers(userId);
          break;

        case 'panel_refresh':
          response = await UserCommands.panelMenu({ from: query.from, chat: query.message.chat });
          break;

        case 'close':
          await bot.deleteMessage(chatId, messageId);
          await bot.answerCallbackQuery(query.id, { text: 'Menu ditutup' });
          return;

        default:
          if (data.startsWith('server_info_')) {
            const serverName = data.replace('server_info_', '');
            response = await this.handleServerInfo(serverName, userId);
          } else if (data.startsWith('server_clear_')) {
            const serverName = data.replace('server_clear_', '');
            response = await this.handleServerClear(serverName, userId);
          } else {
            response = { text: '❌ Perintah tidak dikenal' };
          }
          break;
      }

      if (response) {
        if (response.options) {
          await bot.editMessageText(response.text, {
            chat_id: chatId,
            message_id: messageId,
            ...response.options
          });
        } else {
          await bot.editMessageText(response.text, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'Markdown'
          });
        }
      }

      await bot.answerCallbackQuery(query.id);

    } catch (error) {
      logger.error('Error handling callback query', error);
      
      try {
        await bot.answerCallbackQuery(query.id, {
          text: 'Terjadi kesalahan!',
          show_alert: true
        });
      } catch (e) {
        logger.error('Error answering callback query', e);
      }
    }
  }

  /**
   * Handle create panel menu
   */
  static async handleCreatePanelMenu(userId) {
    const userInfo = authMiddleware.getUserInfo(userId);
    
    if (!userInfo.isPremium) {
      return { text: config.messages.unauthorized };
    }

    const servers = panelService.getAllServers();
    
    if (servers.length === 0) {
      return { text: '❌ Tidak ada server yang tersedia!' };
    }

    let text = `➕ *Buat Panel Baru*\n\n`;
    text += `📋 *Format:*\n`;
    text += `\`/buatpanel username,email,nama_depan,nama_belakang,server\`\n\n`;
    text += `📊 *Server Tersedia:*\n`;
    
    servers.forEach((server, index) => {
      text += `${index + 1}. \`${server.name}\` - ${server.domain}\n`;
    });

    text += `\n💡 *Contoh:*\n`;
    text += `\`/buatpanel john123,john@email.com,John,Doe,${servers[0].name}\``;

    return {
      text,
      options: {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Kembali', callback_data: 'panel' }]
          ]
        }
      }
    };
  }

  /**
   * Handle list panels
   */
  static async handleListPanels(userId) {
    const userInfo = authMiddleware.getUserInfo(userId);
    
    if (!userInfo.isPremium) {
      return { text: config.messages.unauthorized };
    }

    // This would typically fetch from a database
    // For now, we'll show a placeholder
    const text = `📋 *Daftar Panel Anda*\n\n` +
                 `🔄 Fitur ini sedang dalam pengembangan.\n` +
                 `Panel yang dibuat akan ditampilkan di sini.\n\n` +
                 `💡 Gunakan \`/buatpanel\` untuk membuat panel baru.`;

    return {
      text,
      options: {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Kembali', callback_data: 'panel' }]
          ]
        }
      }
    };
  }

  /**
   * Handle manage servers
   */
  static async handleManageServers(userId) {
    const userInfo = authMiddleware.getUserInfo(userId);
    
    if (!userInfo.isAdmin) {
      return { text: config.messages.unauthorized };
    }

    const servers = panelService.getAllServers();
    
    let text = `🛠️ *Kelola Server*\n\n`;
    
    if (servers.length === 0) {
      text += `❌ Tidak ada server yang terdaftar.\n\n`;
      text += `Gunakan \`/addsrv\` untuk menambah server.`;
      
      return {
        text,
        options: {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🔙 Kembali', callback_data: 'panel' }]
            ]
          }
        }
      };
    }

    text += `📊 *Daftar Server (${servers.length}):*\n\n`;

    const keyboard = [];
    
    servers.forEach((server, index) => {
      text += `${index + 1}. **${server.name}**\n`;
      text += `   • Domain: \`${server.domain}\`\n`;
      text += `   • Status: \`${server.status}\`\n\n`;
      
      keyboard.push([
        { text: `ℹ️ Info ${server.name}`, callback_data: `server_info_${server.name}` },
        { text: `🧹 Clear ${server.name}`, callback_data: `server_clear_${server.name}` }
      ]);
    });

    keyboard.push([{ text: '🔙 Kembali', callback_data: 'panel' }]);

    return {
      text,
      options: {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: keyboard
        }
      }
    };
  }

  /**
   * Handle manage users
   */
  static async handleManageUsers(userId) {
    const userInfo = authMiddleware.getUserInfo(userId);
    
    if (!userInfo.isAdmin) {
      return { text: config.messages.unauthorized };
    }

    const admins = authMiddleware.getAdminUsers();
    const premiums = authMiddleware.getPremiumUsers();

    let text = `👥 *Kelola User*\n\n`;
    text += `👑 *Owner:* \`${config.bot.adminId}\`\n\n`;
    
    if (admins.length > 0) {
      text += `🛡️ *Admin (${admins.length}):*\n`;
      admins.forEach((adminId, index) => {
        text += `${index + 1}. \`${adminId}\`\n`;
      });
      text += '\n';
    }

    if (premiums.length > 0) {
      text += `⭐ *Premium (${premiums.length}):*\n`;
      premiums.forEach((premiumId, index) => {
        text += `${index + 1}. \`${premiumId}\`\n`;
      });
    }

    if (admins.length === 0 && premiums.length === 0) {
      text += `Tidak ada admin atau premium user.`;
    }

    text += `\n\n💡 *Perintah:*\n`;
    text += `• \`/addprem <userid>\` - Tambah premium\n`;
    text += `• \`/delprem <userid>\` - Hapus premium\n`;
    
    if (userInfo.isOwner) {
      text += `• \`/addowner <userid>\` - Tambah admin\n`;
      text += `• \`/delowner <userid>\` - Hapus admin`;
    }

    return {
      text,
      options: {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Kembali', callback_data: 'panel' }]
          ]
        }
      }
    };
  }

  /**
   * Handle server info
   */
  static async handleServerInfo(serverName, userId) {
    const userInfo = authMiddleware.getUserInfo(userId);
    
    if (!userInfo.isAdmin) {
      return { text: config.messages.unauthorized };
    }

    const server = panelService.getServer(serverName);
    
    if (!server) {
      return { text: `❌ Server "${serverName}" tidak ditemukan!` };
    }

    const text = `📊 *Info Server: ${server.name}*\n\n` +
                 `🌐 *Domain:* \`${server.domain}\`\n` +
                 `📍 *Location:* \`${server.location}\`\n` +
                 `🥚 *Eggs:* \`${server.eggs}\`\n` +
                 `📊 *Status:* \`${server.status}\`\n` +
                 `📅 *Dibuat:* \`${new Date(server.createdAt).toLocaleString('id-ID')}\`\n` +
                 (server.updatedAt ? `🔄 *Update:* \`${new Date(server.updatedAt).toLocaleString('id-ID')}\`\n` : '') +
                 `\n🔗 *Panel URL:* ${server.domain}`;

    return {
      text,
      options: {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Kembali', callback_data: 'manage_servers' }]
          ]
        }
      }
    };
  }

  /**
   * Handle server clear
   */
  static async handleServerClear(serverName, userId) {
    const userInfo = authMiddleware.getUserInfo(userId);
    
    if (!userInfo.isAdmin) {
      return { text: config.messages.unauthorized };
    }

    const server = panelService.getServer(serverName);
    
    if (!server) {
      return { text: `❌ Server "${serverName}" tidak ditemukan!` };
    }

    // This is a dangerous operation, so we'll just show a confirmation
    const text = `⚠️ *Konfirmasi Clear Server*\n\n` +
                 `Server: **${server.name}**\n` +
                 `Domain: \`${server.domain}\`\n\n` +
                 `❗ *PERINGATAN:*\n` +
                 `Operasi ini akan menghapus SEMUA user dan server dari panel!\n\n` +
                 `Gunakan perintah \`/clearserver\` untuk melanjutkan.`;

    return {
      text,
      options: {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Kembali', callback_data: 'manage_servers' }]
          ]
        }
      }
    };
  }
}

module.exports = CallbackHandler;
