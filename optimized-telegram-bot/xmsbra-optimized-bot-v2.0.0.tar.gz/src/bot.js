const TelegramBot = require('node-telegram-bot-api');
const config = require('./config/config');
const logger = require('./utils/logger');
const authMiddleware = require('./middleware/auth');
const authenticationMiddleware = require('./middleware/authentication');
const groupAccessMiddleware = require('./middleware/groupAccess');
const rateLimiter = require('./middleware/rateLimit');
const UserCommands = require('./commands/userCommands');
const AdminCommands = require('./commands/adminCommands');
const NewCommands = require('./commands/newCommands');
const CallbackHandler = require('./handlers/callbackHandler');
const securityService = require('./services/securityService');
const cleanupService = require('./services/cleanupService');
const similarityMatcher = require('./utils/similarity');
const Helpers = require('./utils/helpers');

class OptimizedTelegramBot {
  constructor() {
    this.bot = null;
    this.isRunning = false;
    this.startTime = Date.now();
    this.commandStats = new Map();
  }

  /**
   * Initialize the bot
   */
  async initialize() {
    try {
      logger.info('Initializing Optimized Telegram Bot v2.0.0...');

      // Create bot instance
      this.bot = new TelegramBot(config.bot.token, {
        polling: {
          interval: config.bot.polling.interval,
          autoStart: false,
          params: config.bot.polling.params
        }
      });

      // Setup error handlers
      this.setupErrorHandlers();

      // Setup command handlers
      this.setupCommandHandlers();

      // Setup callback handlers
      this.setupCallbackHandlers();

      // Setup middleware
      this.setupMiddleware();

      // Initialize services
      await this.initializeServices();

      logger.success('Bot initialized successfully');
      return true;

    } catch (error) {
      logger.error('Failed to initialize bot', error);
      return false;
    }
  }

  /**
   * Initialize services
   */
  async initializeServices() {
    try {
      // Load authentication data
      await authenticationMiddleware.loadAuthData();
      
      // Load group access data
      await groupAccessMiddleware.loadGroupAccess();
      
      // Start auto cleanup if enabled
      if (config.features.autoCleanup) {
        cleanupService.startAutoCleanup();
      }
      
      // Start security monitoring if enabled
      if (config.features.securityMonitoring) {
        await securityService.startMonitoring();
      }

      logger.info('Services initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize services', error);
    }
  }

  /**
   * Start the bot
   */
  async start() {
    try {
      if (this.isRunning) {
        logger.warn('Bot is already running');
        return;
      }

      await this.bot.startPolling();
      this.isRunning = true;

      // Display welcome banner
      await authenticationMiddleware.displayWelcomeBanner();

      logger.success(`Bot started successfully! Runtime: ${Helpers.getRuntime()}`);
      
      // Send startup notification to owner
      try {
        const botInfo = await this.bot.getMe();
        await this.bot.sendMessage(config.bot.adminId[0], 
          `🚀 *XMSBRA CPANEL BOT STARTED*\n\n` +
          `⏰ *Time:* ${new Date().toLocaleString('id-ID')}\n` +
          `🤖 *Bot:* @${botInfo.username}\n` +
          `📊 *Status:* Online\n` +
          `🔧 *Version:* ${config.bot.version}\n\n` +
          `✨ *New Features:*\n` +
          `• 🔐 Password Authentication\n` +
          `• 👥 Group Access Control\n` +
          `• 🛡️ Security Monitoring\n` +
          `• 🧹 Auto Cleanup System\n` +
          `• 📝 Command Similarity\n` +
          `• 🔧 Maintenance Mode`,
          { parse_mode: 'Markdown' }
        );
      } catch (e) {
        logger.warn('Could not send startup notification to owner');
      }

      // Setup periodic tasks
      this.setupPeriodicTasks();

    } catch (error) {
      logger.error('Failed to start bot', error);
      this.isRunning = false;
    }
  }

  /**
   * Stop the bot
   */
  async stop() {
    try {
      if (!this.isRunning) {
        logger.warn('Bot is not running');
        return;
      }

      await this.bot.stopPolling();
      this.isRunning = false;

      // Stop services
      cleanupService.stopAutoCleanup();
      await securityService.stopMonitoring();

      // Cleanup
      rateLimiter.destroy();

      logger.info('Bot stopped successfully');

    } catch (error) {
      logger.error('Error stopping bot', error);
    }
  }

  /**
   * Setup error handlers
   */
  setupErrorHandlers() {
    this.bot.on('error', (error) => {
      logger.error('Bot error', error);
    });

    this.bot.on('polling_error', (error) => {
      logger.error('Polling error', error);
    });

    // Global error handlers
    process.on('uncaughtException', (error) => {
      logger.error('Uncaught Exception', error);
    });

    process.on('unhandledRejection', (reason, promise) => {
      logger.error('Unhandled Rejection', new Error(reason));
    });
  }

  /**
   * Setup command handlers
   */
  setupCommandHandlers() {
    // Authentication command (no middleware)
    this.bot.onText(/^\/auth (.+)/, this.handleCommand('auth', NewCommands.authenticate));

    // Basic commands with authentication
    this.bot.onText(/^\/start$/, this.handleCommand('start', 
      this.withAuth(UserCommands.start)));
    
    this.bot.onText(/^\/help$/, this.handleCommand('help', 
      this.withAuth(UserCommands.help)));
    
    this.bot.onText(/^\/cekid$/, this.handleCommand('cekid', 
      this.withAuth(UserCommands.checkId)));
    
    this.bot.onText(/^\/panel$/, this.handleCommand('panel', 
      this.withAuth(UserCommands.panelMenu)));
    
    this.bot.onText(/^\/status$/, this.handleCommand('status', 
      this.withAuth(UserCommands.status)));

    // Premium commands
    this.bot.onText(/^\/buatpanel (.+)/, this.handleCommand('buatpanel', 
      this.withAuth(authMiddleware.premiumOnly(rateLimiter.rateLimit(UserCommands.createPanel)))));

    // Admin commands
    this.bot.onText(/^\/addsrv (.+)/, this.handleCommand('addsrv',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.addServer))));
    
    this.bot.onText(/^\/listsrv$/, this.handleCommand('listsrv',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.listServers))));
    
    this.bot.onText(/^\/delsrv (.+)/, this.handleCommand('delsrv',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.deleteServer))));
    
    this.bot.onText(/^\/srvinfo (.+)/, this.handleCommand('srvinfo',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.serverInfo))));
    
    this.bot.onText(/^\/addprem (.+)/, this.handleCommand('addprem',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.addPremium))));
    
    this.bot.onText(/^\/delprem (.+)/, this.handleCommand('delprem',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.removePremium))));
    
    this.bot.onText(/^\/listadmin$/, this.handleCommand('listadmin',
      this.withAuth(authMiddleware.adminOnly(AdminCommands.listAdmins))));

    // New admin commands
    this.bot.onText(/^\/addgc (.+)/, this.handleCommand('addgc',
      this.withAuth(authMiddleware.adminOnly(NewCommands.addGroupAccess))));
    
    this.bot.onText(/^\/delgc (.+)/, this.handleCommand('delgc',
      this.withAuth(authMiddleware.adminOnly(NewCommands.removeGroupAccess))));
    
    this.bot.onText(/^\/listgc$/, this.handleCommand('listgc',
      this.withAuth(authMiddleware.adminOnly(NewCommands.listGroupAccess))));
    
    this.bot.onText(/^\/joingc (.+)/, this.handleCommand('joingc',
      this.withAuth(authMiddleware.adminOnly(NewCommands.joinGroup))));
    
    this.bot.onText(/^\/ban (.+)/, this.handleCommand('ban',
      this.withAuth(authMiddleware.adminOnly(NewCommands.banUser))));
    
    this.bot.onText(/^\/unban (.+)/, this.handleCommand('unban',
      this.withAuth(authMiddleware.adminOnly(NewCommands.unbanUser))));
    
    this.bot.onText(/^\/security_panel (.+)/, this.handleCommand('security_panel',
      this.withAuth(authMiddleware.adminOnly(NewCommands.securityPanel))));

    // Owner commands
    this.bot.onText(/^\/addowner (.+)/, this.handleCommand('addowner',
      this.withAuth(authMiddleware.ownerOnly(AdminCommands.addAdmin))));
    
    this.bot.onText(/^\/delowner (.+)/, this.handleCommand('delowner',
      this.withAuth(authMiddleware.ownerOnly(AdminCommands.removeAdmin))));
    
    this.bot.onText(/^\/clearserver$/, this.handleCommand('clearserver',
      this.withAuth(authMiddleware.ownerOnly(AdminCommands.clearServer))));
    
    this.bot.onText(/^\/stats$/, this.handleCommand('stats',
      this.withAuth(authMiddleware.ownerOnly(AdminCommands.botStats))));
    
    this.bot.onText(/^\/maintenance (.+)/, this.handleCommand('maintenance',
      this.withAuth(authMiddleware.ownerOnly(NewCommands.maintenanceMode))));
    
    this.bot.onText(/^\/cleanup (.+)/, this.handleCommand('cleanup',
      this.withAuth(authMiddleware.ownerOnly(NewCommands.cleanupCommand))));
  }

  /**
   * Setup callback handlers
   */
  setupCallbackHandlers() {
    this.bot.on('callback_query', async (query) => {
      // Check authentication for callback queries too
      const authCheck = authenticationMiddleware.requireAuth();
      const authResult = await authCheck({ from: query.from, chat: query.message.chat });
      
      if (authResult) {
        try {
          await this.bot.answerCallbackQuery(query.id, {
            text: 'Autentikasi diperlukan!',
            show_alert: true
          });
        } catch (e) {
          logger.error('Error answering callback query', e);
        }
        return;
      }

      await CallbackHandler.handle(this.bot, query);
    });
  }

  /**
   * Setup middleware
   */
  setupMiddleware() {
    // Log all messages with fancy display
    this.bot.on('message', (msg) => {
      if (msg.text && msg.text.startsWith('/')) {
        const command = msg.text.split(' ')[0];
        authenticationMiddleware.logCommand(msg, command);
        
        // Check command similarity if enabled
        if (config.features.similarity && !this.isValidCommand(command)) {
          this.handleSimilarity(msg, command);
        }
      }
    });
  }

  /**
   * Check if command is valid
   */
  isValidCommand(command) {
    const cleanCommand = command.replace(/^\//, '').toLowerCase();
    const allCommands = [
      ...config.commands.public,
      ...config.commands.premium,
      ...config.commands.admin,
      ...config.commands.owner
    ];
    
    return allCommands.includes(cleanCommand);
  }

  /**
   * Handle command similarity
   */
  async handleSimilarity(msg, command) {
    try {
      const suggestion = NewCommands.processCommandSimilarity(command);
      
      if (suggestion) {
        await this.bot.sendMessage(msg.chat.id, suggestion.text, suggestion.options);
      }
    } catch (error) {
      logger.error('Error handling similarity', error);
    }
  }

  /**
   * Wrap handler with authentication
   */
  withAuth(handler) {
    return async (msg, match) => {
      const authCheck = authenticationMiddleware.requireAuth();
      const authResult = await authCheck(msg, match);
      
      if (authResult) {
        return authResult;
      }
      
      return await handler(msg, match);
    };
  }

  /**
   * Handle command with error handling and stats
   */
  handleCommand(commandName, handler) {
    return async (msg, match) => {
      const startTime = Date.now();
      
      try {
        // Update command stats
        const currentCount = this.commandStats.get(commandName) || 0;
        this.commandStats.set(commandName, currentCount + 1);

        // Execute command
        const result = await handler(msg, match);
        
        if (result) {
          if (result.error) {
            await this.bot.sendMessage(msg.chat.id, result.error, {
              parse_mode: 'Markdown'
            });
          } else {
            const options = result.options || { parse_mode: 'Markdown' };
            await this.bot.sendMessage(msg.chat.id, result.text, options);
          }
        }

        const responseTime = Date.now() - startTime;
        logger.debug(`Command ${commandName} executed in ${responseTime}ms`);

      } catch (error) {
        logger.error(`Error in command ${commandName}`, error);
        
        try {
          await this.bot.sendMessage(msg.chat.id, config.messages.error, {
            parse_mode: 'Markdown'
          });
        } catch (sendError) {
          logger.error('Failed to send error message', sendError);
        }
      }
    };
  }

  /**
   * Setup periodic tasks
   */
  setupPeriodicTasks() {
    // Clean old logs every day
    setInterval(async () => {
      try {
        await logger.cleanOldLogs(7);
      } catch (error) {
        logger.error('Error cleaning old logs', error);
      }
    }, 24 * 60 * 60 * 1000); // 24 hours

    // Send daily stats to owner
    setInterval(async () => {
      try {
        await this.sendDailyStats();
      } catch (error) {
        logger.error('Error sending daily stats', error);
      }
    }, 24 * 60 * 60 * 1000); // 24 hours

    // Memory usage check every hour
    setInterval(() => {
      const memUsage = process.memoryUsage();
      const heapUsedMB = Math.round(memUsage.heapUsed / 1024 / 1024);
      
      if (heapUsedMB > 500) { // Alert if using more than 500MB
        logger.warn(`High memory usage: ${heapUsedMB}MB`);
      }
    }, 60 * 60 * 1000); // 1 hour

    // Security alert forwarding
    setInterval(async () => {
      try {
        await this.forwardSecurityAlerts();
      } catch (error) {
        logger.error('Error forwarding security alerts', error);
      }
    }, 60 * 1000); // 1 minute
  }

  /**
   * Forward security alerts to owner
   */
  async forwardSecurityAlerts() {
    try {
      const alerts = securityService.getRecentAlerts(10);
      const unnotified = alerts.filter(alert => !alert.notified);
      
      for (const alert of unnotified) {
        let message = '';
        
        if (alert.type === 'suspicious_login') {
          message = `🚨 *PERINGATAN KEAMANAN*\n\n` +
                    `⚠️ *Wah Ada Yang Ngintip Panel Nih*\n\n` +
                    `👤 *Username:* \`${alert.data.username}\`\n` +
                    `📧 *Email:* \`${alert.data.email}\`\n` +
                    `🌐 *IP:* \`${alert.data.ip}\`\n` +
                    `🖥️ *Server:* \`${alert.data.server}\`\n` +
                    `⏰ *Waktu:* ${new Date(alert.data.timestamp).toLocaleString('id-ID')}`;
        } else if (alert.type === 'suspicious_file_access') {
          message = `🚨 *PERINGATAN KEAMANAN*\n\n` +
                    `⚠️ *Wah Ada Yang Ngambil Script Orang Nih*\n\n` +
                    `👤 *Username:* \`${alert.data.username}\`\n` +
                    `📧 *Email:* \`${alert.data.email}\`\n` +
                    `🌐 *IP:* \`${alert.data.ip}\`\n` +
                    `📁 *File:* \`${alert.data.file}\`\n` +
                    `🔧 *Action:* \`${alert.data.action}\`\n` +
                    `🖥️ *Server:* \`${alert.data.server}\`\n` +
                    `⏰ *Waktu:* ${new Date(alert.data.timestamp).toLocaleString('id-ID')}`;
        }

        if (message) {
          await this.bot.sendMessage(config.bot.adminId[0], message, {
            parse_mode: 'Markdown'
          });
          
          alert.notified = true;
        }
      }
    } catch (error) {
      logger.error('Error forwarding security alerts', error);
    }
  }

  /**
   * Send daily stats to owner
   */
  async sendDailyStats() {
    try {
      const runtime = Helpers.getRuntime();
      const memUsage = process.memoryUsage();
      const rateLimitStats = rateLimiter.getStats();
      const authStats = authenticationMiddleware.getStats();
      const securityStats = securityService.getSecurityStats();
      const cleanupStats = cleanupService.getCleanupStats();
      
      let statsText = `📊 *DAILY BOT STATS*\n\n`;
      statsText += `⏱️ *Runtime:* ${runtime}\n`;
      statsText += `🖥️ *Memory:* ${Helpers.formatBytes(memUsage.heapUsed)}\n`;
      statsText += `👥 *Active Users:* ${rateLimitStats.activeUsers}\n`;
      statsText += `📨 *Total Requests:* ${rateLimitStats.totalRequests}\n\n`;
      
      statsText += `🔐 *Authentication:*\n`;
      statsText += `• Authenticated: ${authStats.authenticated}\n`;
      statsText += `• Banned: ${authStats.banned}\n`;
      statsText += `• Maintenance: ${authStats.maintenanceMode ? 'ON' : 'OFF'}\n\n`;
      
      statsText += `🛡️ *Security:*\n`;
      statsText += `• Monitoring: ${securityStats.monitoring ? 'ON' : 'OFF'}\n`;
      statsText += `• Alerts 24h: ${securityStats.recentAlerts}\n`;
      statsText += `• Trusted Users: ${securityStats.trustedUsers}\n\n`;
      
      statsText += `🧹 *Cleanup:*\n`;
      statsText += `• Auto Cleanup: ${cleanupStats.autoCleanup ? 'ON' : 'OFF'}\n`;
      statsText += `• Last Cleanup: ${cleanupStats.lastCleanup ? new Date(cleanupStats.lastCleanup).toLocaleString('id-ID') : 'Never'}\n`;
      statsText += `• Avg Inactive: ${cleanupStats.averageInactive}\n\n`;
      
      if (this.commandStats.size > 0) {
        statsText += `📋 *Command Usage:*\n`;
        const sortedCommands = Array.from(this.commandStats.entries())
          .sort((a, b) => b[1] - a[1])
          .slice(0, 10);
        
        sortedCommands.forEach(([cmd, count]) => {
          statsText += `• \`${cmd}\`: ${count}x\n`;
        });
      }

      await this.bot.sendMessage(config.bot.adminId[0], statsText, {
        parse_mode: 'Markdown'
      });

    } catch (error) {
      logger.error('Failed to send daily stats', error);
    }
  }

  /**
   * Get bot info
   */
  async getBotInfo() {
    try {
      const botInfo = await this.bot.getMe();
      return {
        id: botInfo.id,
        username: botInfo.username,
        firstName: botInfo.first_name,
        isRunning: this.isRunning,
        uptime: Helpers.getRuntime(),
        commandStats: Object.fromEntries(this.commandStats),
        features: config.features
      };
    } catch (error) {
      logger.error('Failed to get bot info', error);
      return null;
    }
  }
}

module.exports = OptimizedTelegramBot;
