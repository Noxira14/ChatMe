# 🤖 XMSBRA Optimized Telegram Bot v2.0.0

Advanced Telegram Bot for cPanel Management with Enterprise-Level Features

## 🌟 Features

### 🔐 Security & Authentication
- **Password Authentication**: Initial bot access requires password verification
- **Multi-level User Management**: Owner → Admin → Premium → Regular users
- **Rate Limiting**: 30 requests/minute per user with automatic cleanup
- **Ban/Unban System**: Complete user access control
- **Maintenance Mode**: Bot-wide maintenance toggle

### 👥 Group Management
- **Group Access Control**: Add group-specific premium access for resellers/admins
- **Join Group Command**: Automated group joining functionality
- **Group-specific Permissions**: Fine-grained access control per group

### 🛡️ Security Monitoring
- **Real-time Panel Monitoring**: Monitor unauthorized panel access
- **Security Alerts**: Instant notifications for suspicious activities
- **Trusted User System**: Whitelist trusted users to reduce false alerts
- **Activity Logging**: Comprehensive security event logging

### 🧹 Automated Cleanup
- **Auto Cleanup System**: Automated server cleanup every 5 hours
- **Inactive User Detection**: Identify users inactive for >2 days
- **Owner Notifications**: Detailed cleanup reports
- **Manual Cleanup**: On-demand cleanup execution

### 📝 Enhanced Logging
- **Colorful Console Logging**: Figlet-based command logging with rainbow colors
- **Structured JSON Logging**: Daily file rotation with 7-day retention
- **Performance Tracking**: Response time monitoring for all commands
- **Memory Usage Monitoring**: Automatic alerts for high memory usage

### 🔍 Command Intelligence
- **Command Similarity**: Suggest similar commands when typos occur
- **Interactive Suggestions**: Clickable command suggestions
- **Smart Error Handling**: Comprehensive error recovery

### 📊 Advanced Analytics
- **Daily Statistics**: Automated daily reports to owner
- **Command Usage Tracking**: Monitor most used commands
- **Performance Metrics**: Response time and memory usage stats
- **User Activity Analytics**: Track user engagement

## 🚀 Installation

### Prerequisites
- Node.js >= 16.0.0
- npm >= 8.0.0
- Telegram Bot Token
- Pterodactyl Panel API Keys

### Quick Setup

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/optimized-telegram-bot.git
cd optimized-telegram-bot
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment**
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. **Create required directories**
```bash
mkdir -p data logs
```

5. **Start the bot**
```bash
npm start
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
# Bot Configuration
BOT_TOKEN=your_telegram_bot_token_here
ADMIN_ID=your_telegram_user_id
BOT_PASSWORD=XMSBRA2024

# Panel Configuration
DOMAIN=https://your-panel-domain.com
PLTA=your_application_api_key_here
PLTC=your_client_api_key_here
LOCATION=1
EGGS=15

# Security Configuration
MAX_REQUESTS_PER_MINUTE=30
SESSION_TIMEOUT=3600000
PASSWORD_LENGTH=12

# Logging Configuration
LOG_LEVEL=info

# Optional Configuration
PROFILE_PICTURE=https://files.catbox.moe/7l5fvh.jpg
ADMIN_URL=https://t.me/yourusername
```

### Directory Structure

```
optimized-telegram-bot/
├── src/
│   ├── commands/
│   │   ├── adminCommands.js      # Admin-only commands
│   │   ├── userCommands.js       # User commands
│   │   └── newCommands.js        # New feature commands
│   ├── middleware/
│   │   ├── auth.js               # Authentication middleware
│   │   ├── authentication.js    # Password auth system
│   │   ├── groupAccess.js        # Group access control
│   │   └── rateLimit.js          # Rate limiting
│   ├── services/
│   │   ├── panelService.js       # Panel API integration
│   │   ├── securityService.js    # Security monitoring
│   │   └── cleanupService.js     # Automated cleanup
│   ├── utils/
│   │   ├── helpers.js            # Utility functions
│   │   ├── logger.js             # Logging system
│   │   └── similarity.js         # Command similarity
│   ├── handlers/
│   │   └── callbackHandler.js    # Callback query handler
│   ├── config/
│   │   └── config.js             # Configuration management
│   └── bot.js                    # Main bot class
├── data/                         # Data storage
├── logs/                         # Log files
├── index.js                      # Entry point
├── package.json                  # Dependencies
├── .env.example                  # Environment template
└── README.md                     # Documentation
```

## 📋 Commands

### 🔓 Public Commands
- `/start` - Welcome message and bot info
- `/help` - Display help menu
- `/cekid` - Check your Telegram ID
- `/auth <password>` - Authenticate with bot

### 💎 Premium Commands
- `/buatpanel <email> <username> <name>` - Create new panel account
- `/listpanel` - List your panel accounts
- `/delpanel <username>` - Delete panel account
- `/panel` - Panel management menu
- `/status` - Check bot status

### 👑 Admin Commands
- `/addsrv <name> <domain> <apikey>` - Add new server
- `/listsrv` - List all servers
- `/delsrv <name>` - Delete server
- `/srvinfo <name>` - Server information
- `/addprem <user_id>` - Add premium user
- `/delprem <user_id>` - Remove premium user
- `/listadmin` - List all admins
- `/addgc <group_id> <type>` - Add group access
- `/delgc <group_id>` - Remove group access
- `/listgc` - List group accesses
- `/joingc <invite_link>` - Join group
- `/ban <user_id>` - Ban user
- `/unban <user_id>` - Unban user
- `/security_panel <action>` - Security monitoring

### 🔱 Owner Commands
- `/addowner <user_id>` - Add admin/owner
- `/delowner <user_id>` - Remove admin/owner
- `/clearserver` - Clear all servers
- `/stats` - Bot statistics
- `/maintenance <on|off|status>` - Maintenance mode
- `/cleanup <start|stop|run|status|history>` - Cleanup system

## 🔧 Advanced Features

### Security Monitoring

The bot includes advanced security monitoring that:
- Monitors panel login attempts
- Detects suspicious file access
- Tracks unauthorized activities
- Sends real-time alerts to owners
- Maintains trusted user whitelist

**Usage:**
```bash
/security_panel start    # Start monitoring
/security_panel stop     # Stop monitoring
/security_panel status   # Check status
/security_panel alerts   # View recent alerts
```

### Automated Cleanup

Automated cleanup system that:
- Runs every 5 hours automatically
- Identifies inactive users (>2 days)
- Generates detailed reports
- Notifies owners of findings
- Supports manual cleanup execution

**Usage:**
```bash
/cleanup start     # Start auto cleanup
/cleanup stop      # Stop auto cleanup
/cleanup run       # Manual cleanup
/cleanup status    # Check status
/cleanup history   # View history
```

### Group Access Control

Advanced group management:
- Reseller access for specific groups
- Admin privileges for management groups
- Fine-grained permission control
- Automatic access validation

**Usage:**
```bash
/addgc -1001234567890 reseller    # Add reseller group
/addgc -1001234567890 admin       # Add admin group
/listgc                           # List all groups
/delgc -1001234567890            # Remove group access
```

### Command Similarity

Smart command suggestions:
- Detects typos in commands
- Suggests similar valid commands
- Interactive correction buttons
- Configurable similarity threshold

## 📊 Monitoring & Analytics

### Daily Statistics
- Runtime and uptime tracking
- Memory usage monitoring
- Command usage analytics
- User activity reports
- Security event summaries

### Performance Monitoring
- Response time tracking
- Memory usage alerts
- Rate limiting statistics
- Error rate monitoring

### Security Analytics
- Login attempt tracking
- Suspicious activity detection
- Alert frequency analysis
- Trusted user management

## 🛠️ Development

### Running in Development Mode
```bash
npm run dev
```

### Viewing Logs
```bash
npm run logs
```

### Cleaning Data
```bash
npm run clean
```

### Creating Backup
```bash
npm run backup
```

## 🔒 Security Best Practices

1. **Environment Variables**: Never commit `.env` files
2. **API Keys**: Rotate API keys regularly
3. **Password**: Use strong bot passwords
4. **Rate Limiting**: Monitor for abuse patterns
5. **Logging**: Review logs regularly for anomalies
6. **Updates**: Keep dependencies updated
7. **Backups**: Regular data backups

## 🐛 Troubleshooting

### Common Issues

**Bot not responding:**
- Check bot token validity
- Verify network connectivity
- Review error logs

**Authentication failures:**
- Verify bot password
- Check user permissions
- Review authentication logs

**Panel connection issues:**
- Validate API keys
- Check panel domain accessibility
- Review panel service logs

**Memory issues:**
- Monitor memory usage
- Check for memory leaks
- Review cleanup processes

### Log Locations
- Application logs: `logs/app.log`
- Error logs: `logs/error.log`
- Security logs: `logs/security.log`

## 📈 Performance Optimization

### Memory Management
- Automatic cleanup of old data
- Efficient data structures
- Memory usage monitoring
- Garbage collection optimization

### Response Time
- Async/await patterns
- Connection pooling
- Request caching
- Error handling optimization

### Scalability
- Modular architecture
- Service separation
- Configuration management
- Resource monitoring

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Telegram Bot API
- Pterodactyl Panel
- Node.js Community
- Open Source Contributors

## 📞 Support

- **Telegram**: [@yourusername](https://t.me/yourusername)
- **Issues**: [GitHub Issues](https://github.com/yourusername/optimized-telegram-bot/issues)
- **Documentation**: [Wiki](https://github.com/yourusername/optimized-telegram-bot/wiki)

---

**Made with ❤️ by XMSBRA Team**

*Version 2.0.0 - Enterprise Edition*
